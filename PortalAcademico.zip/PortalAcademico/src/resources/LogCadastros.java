package resources;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParseException;
import java.util.Date;
import java.util.Random;

import javax.swing.JLabel;

import applicationExceptions.ResourcesException;
import gui.ProgramaPrincipal;
import users.Docente;
import users.Estudante;
import users.Pessoa;

public abstract class LogCadastros extends Log {
	protected static int qntLinhas;
	protected static int qntDocentes;

	public static int contador() {
		/*
		 * Esse método conta quantas linhas o arquivo, armazenando a contagem em
		 * qntLinhas (que é setada em 0 a cada chamada do método) e, ao final,
		 * retornando a varíavel. A sua função é auxiliar a classe ListarCadastros no
		 * Painel Do Administrador na montagem da tabela. É criado um leitor de arquivo
		 * do tipo BufferedReader a partir do FileReader baseado no pathCadastros
		 * (String do caminho do arquivo). Enquanto o leitor "br" não chegar ao fim do
		 * arquivo, o contador é incrementado e a leitura avança à próxima linha. No
		 * fim, o leitor é fechado.
		 */
		String pathCadastros = Log.getPath("logCadastros.txt");
		qntLinhas = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(pathCadastros))) {
			String linha = br.readLine();
			while (linha != null) {
				qntLinhas++;
				linha = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return qntLinhas;
	}

	public static void adicionar(Pessoa p) {
		/*
		 * Esse método recebe um objeto da classe Pessoa como parâmetro e realiza várias
		 * operações. Primeiro, ele chama o método "adicionarCredenciais" da classe
		 * LogLogins para adicionar as credenciais da pessoa. Em seguida, ele abre um
		 * arquivo para escrita no caminho especificado em pathCadastros e cria um
		 * BufferedWriter dentro de um bloco try-with-resources. Antes de escrever os
		 * detalhes da pessoa no arquivo, ele verifica se o arquivo já possui algum
		 * conteúdo e, se for o caso, insere uma quebra de linha. Depois, escreve CPF,
		 * nome, data de nascimento, identificador, ano de ingresso e nome da classe
		 * (atribuição do usuário, isto é, docente ou estudante) no arquivo. Em seguida,
		 * fecha o "BufferedWriter". Além disso, dependendo do tipo de pessoa (se é
		 * Estudante ou Docente), o método realiza ações adicionais. Se for Estudante,
		 * ele abre dois arquivos adicionais e escreve o nome da pessoa em cada um deles
		 * junto a um caractere de dois pontos. Ele também verifica se esses arquivos já
		 * possuem conteúdo antes de escrever. Por outro lado, se a pessoa for Docente,
		 * o método abre um arquivo adicional e escreve o nome da pessoa nele. Também
		 * verifica se o arquivo já possui conteúdo antes de escrever.
		 */
		String pathCadastros = Log.getPath("logCadastros.txt");
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		boolean erro = false;
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(pathCadastros, StandardCharsets.UTF_8, true))) {
			if (!verificarClasseCadastro(String.valueOf(p.getID())).equals("Inconclusivo")) {
				throw new ResourcesException("Usuário já encontra-se cadastrado no sistema. Interrompendo cadastro!");
			}
			if (new File(pathCadastros).length() > 0) {
				bw.newLine();
			}
			bw.write(p.getCPF() + "," + p.getNome() + "," + sdf.format(p.getDataDeNascimento()) + "," + p.getID() + ","
					+ String.valueOf(p.getAnoDeIngresso()) + "," + p.nomeDaClasse());
			bw.close();
			if (p.nomeDaClasse().equals("Estudante")) {
				try (BufferedWriter bwDisciplinasEstudante = new BufferedWriter(
						new FileWriter(pathDisciplinasEstudante, StandardCharsets.UTF_8, true))) {
					if (new File(pathDisciplinasEstudante).length() > 0) {
						bwDisciplinasEstudante.newLine();
					}
					bwDisciplinasEstudante.write(p.getNome() + ":");
					bwDisciplinasEstudante.close();
				}
				try (BufferedWriter bwNotasPorEstudante = new BufferedWriter(
						new FileWriter(pathNotasEstudante, StandardCharsets.UTF_8, true))) {
					if (new File(pathNotasEstudante).length() > 0) {
						bwNotasPorEstudante.newLine();
					}
					bwNotasPorEstudante.write(p.getNome() + ":");
					bwNotasPorEstudante.close();
				}
			} else if (p.nomeDaClasse().equals("Docente")) {
				try (BufferedWriter bwDisciplinasDocente = new BufferedWriter(
						new FileWriter(pathDisciplinasDocente, StandardCharsets.UTF_8, true))) {
					if (new File(pathDisciplinasDocente).length() > 0) {
						bwDisciplinasDocente.newLine();
					}
					bwDisciplinasDocente.write(p.getNome() + ":");
					bwDisciplinasDocente.close();
				}
			}
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (!erro) {
			ProgramaPrincipal.showSuccessMessage(new JLabel("SUCESSO AO CADASTRAR USUÁRIO!"));
			LogLogins.adicionarCredenciais(p);
		} else {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO CADASTRAR USUÁRIO!"));
		}
		Log.codificarUTF8(pathCadastros);
		Log.codificarUTF8(pathDisciplinasEstudante);
		Log.codificarUTF8(pathDisciplinasDocente);
		Log.codificarUTF8(pathNotasEstudante);
	}

	public static void remover(String identificador) {
		/*
		 * Esse método faz, basicamente, o oposto do anterior, tem a finalidade de
		 * remover um usuário dos arquivos do sistema. Recebe como parâmetro um
		 * identificador de usuário (matrícula ou SIAPE) e abre o arquivo de cadastros
		 * correspondente. O método lê o arquivo linha por linha e divide cada linha em
		 * partes usando vírgulas para obter informações sobre o usuário. Se o
		 * identificador do usuário fornecido corresponder ao encontrado na linha, o
		 * método verifica o tipo de usuário com base no valor na posição 5 do array de
		 * informações. Para Docentes, o método encontra o docente com o SIAPE
		 * fornecido, remove suas credenciais de acesso (classe LogLogins), abre um
		 * arquivo de disciplinas de docente e remove as informações relacionadas a esse
		 * docente. Para Estudantes, o método encontra o estudante com a matrícula
		 * fornecida, remove suas credenciais de acesso (classe LogLogins), e abre
		 * arquivos de disciplinas de estudante e notas de estudante, removendo as
		 * informações relacionadas ao estudante. Para todos os tipos de usuários, o
		 * método cria um novo conteúdo sem o usuário removido, escreve de volta no
		 * arquivo de cadastros e exibe uma mensagem de erro se o usuário não for
		 * encontrado.
		 */
		String pathCadastros = Log.getPath("logCadastros.txt");
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		File arquivoDeEntrada = new File(pathCadastros);
		String atribuição = null;
		Estudante auxEstudante = null;
		Docente auxDocente = null;
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			if (verificarClasseCadastro(identificador).equals("Inconclusivo")) {
				throw new ResourcesException("Usuário não se encontra cadastrado no sistema. Interrompendo remoção!");
			}
			StringBuilder novoConteudo = new StringBuilder();
			boolean usuarioEncontrado = false;
			String linha = br.readLine();
			boolean isPrimeiraLinha = true;

			while (linha != null) {
				String divideInformacao[] = linha.split(",");
				if (divideInformacao[3].equals(identificador)) {
					usuarioEncontrado = true;
					atribuição = divideInformacao[5];
					if (atribuição.equals("Docente")) {
						auxDocente = encontrarDocente(identificador);
						LogLogins.removerCredenciais(auxDocente);
						arquivoDeEntrada = new File(pathDisciplinasDocente);
						try (BufferedReader brDisciplinasDocente = new BufferedReader(
								new FileReader(arquivoDeEntrada))) {
							StringBuilder novoConteudoDisciplinasDocente = new StringBuilder();
							boolean usuarioEncontradoDisciplinasDocente = false;
							String linhaDisciplinasDocente = brDisciplinasDocente.readLine();
							boolean isPrimeiraLinhaDisciplinasDocente = true;
							String nome = auxDocente.getNome();

							while (linhaDisciplinasDocente != null) {
								String divideInformacaoDisciplinasDocente[] = linhaDisciplinasDocente.split(":");
								if (divideInformacaoDisciplinasDocente[0].equals(nome)) {
									usuarioEncontradoDisciplinasDocente = true;
								} else {
									if (!isPrimeiraLinhaDisciplinasDocente) {
										novoConteudoDisciplinasDocente.append(System.lineSeparator());
									}
									novoConteudoDisciplinasDocente.append(linhaDisciplinasDocente);
								}
								isPrimeiraLinhaDisciplinasDocente = false;
								linhaDisciplinasDocente = brDisciplinasDocente.readLine();
							}
							brDisciplinasDocente.close();
							if (usuarioEncontradoDisciplinasDocente) {
								Files.write(arquivoDeEntrada.toPath(),
										novoConteudoDisciplinasDocente.toString().getBytes());
							} else {
								throw new ResourcesException(
										"Usuário não encontrado no arquivo de Disciplinas dos Docentes");
							}
						} catch (IOException e) {
							erro = true;
							e.printStackTrace();
						}
					} else if (atribuição.equals("Estudante")) {
						auxEstudante = encontrarEstudante(identificador);
						LogLogins.removerCredenciais(auxEstudante);
						arquivoDeEntrada = new File(pathDisciplinasEstudante);
						try (BufferedReader brDisciplinasEstudante = new BufferedReader(
								new FileReader(arquivoDeEntrada))) {
							StringBuilder novoConteudoDisciplinasEstudante = new StringBuilder();
							boolean usuarioEncontradoDisciplinasEstudante = false;
							String linhaDisciplinasEstudante = brDisciplinasEstudante.readLine();
							boolean isPrimeiraLinhaDisciplinasEstudante = true;
							String nome = auxEstudante.getNome();

							while (linhaDisciplinasEstudante != null) {
								String divideInformacaoDisciplinasEstudante[] = linhaDisciplinasEstudante.split(":");
								if (divideInformacaoDisciplinasEstudante[0].equals(nome)) {
									usuarioEncontradoDisciplinasEstudante = true;
								} else {
									if (!isPrimeiraLinhaDisciplinasEstudante) {
										novoConteudoDisciplinasEstudante.append(System.lineSeparator());
									}
									novoConteudoDisciplinasEstudante.append(linhaDisciplinasEstudante);
								}
								isPrimeiraLinhaDisciplinasEstudante = false;
								linhaDisciplinasEstudante = brDisciplinasEstudante.readLine();
							}
							brDisciplinasEstudante.close();
							if (usuarioEncontradoDisciplinasEstudante) {
								Files.write(arquivoDeEntrada.toPath(),
										novoConteudoDisciplinasEstudante.toString().getBytes());
							} else {
								throw new ResourcesException(
										"Usuário não encontrado no arquivo de Disciplinas dos Estudantes");
							}
						} catch (IOException e) {
							erro = true;
							e.printStackTrace();
						}
						arquivoDeEntrada = new File(pathNotasEstudante);
						try (BufferedReader brNotasEstudante = new BufferedReader(new FileReader(arquivoDeEntrada))) {
							StringBuilder novoConteudoNotasEstudante = new StringBuilder();
							boolean usuarioEncontradoNotasEstudante = false;
							String linhaNotasEstudante = brNotasEstudante.readLine();
							boolean isPrimeiraLinhaNotasEstudante = true;
							String nome = auxEstudante.getNome();

							while (linhaNotasEstudante != null) {
								String divideInformacaoNotasEstudante[] = linhaNotasEstudante.split(":");
								if (divideInformacaoNotasEstudante[0].equals(nome)) {
									usuarioEncontradoNotasEstudante = true;
								} else {
									if (!isPrimeiraLinhaNotasEstudante) {
										novoConteudoNotasEstudante.append(System.lineSeparator());
									}
									novoConteudoNotasEstudante.append(linhaNotasEstudante);
								}
								isPrimeiraLinhaNotasEstudante = false;
								linhaNotasEstudante = brNotasEstudante.readLine();
							}
							brNotasEstudante.close();
							if (usuarioEncontradoNotasEstudante) {
								Files.write(arquivoDeEntrada.toPath(),
										novoConteudoNotasEstudante.toString().getBytes());
							} else {
								throw new ResourcesException(
										"Usuário não encontrado no arquivo de Notas dos Estudantes");
							}
						} catch (IOException e) {
							erro = true;
							e.printStackTrace();
						}
					}
				} else {
					if (!isPrimeiraLinha) {
						novoConteudo.append(System.lineSeparator());
					}
					novoConteudo.append(linha);
				}
				isPrimeiraLinha = false;
				linha = br.readLine();
			}
			br.close();
			arquivoDeEntrada = new File(pathCadastros);
			if (usuarioEncontrado && !erro) {
				Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
				ProgramaPrincipal.showSuccessMessage(new JLabel("USUÁRIO REMOVIDO COM SUCESSO!"));
			} else {
				erro = true;
			}
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO NA REMOÇÃO DE USUÁRIO!"));
		}
		Log.codificarUTF8(pathCadastros);
		Log.codificarUTF8(pathDisciplinasEstudante);
		Log.codificarUTF8(pathDisciplinasDocente);
		Log.codificarUTF8(pathNotasEstudante);
	}

	public static void alterarMatricula(String matriculaAtual, String matriculaNova) {
		/*
		 * Esse método altera a matrícula de um estudante em arquivo. Ele começa abrindo
		 * um BufferedReader e lê suas linhas, dividindo cada linha em partes separadas
		 * por vírgulas. Se a matrícula atual for encontrada na linha, ocorre a
		 * substituição pela nova matrícula. Em seguida, o método reconstroi a linha com
		 * a matrícula alterada e a adiciona a um StringBuilder. Após processar todas as
		 * linhas do arquivo, o conteúdo original do arquivo é substituído pelo novo
		 * conteúdo criado no StringBuilder. O método também registra a alteração no
		 * arquivo de log de logins.
		 */
		String pathCadastros = Log.getPath("logCadastros.txt");
		File arquivoDeEntrada = new File(pathCadastros);
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			if (matriculaAtual.equals("") || matriculaAtual == null || matriculaNova.equals("")
					|| matriculaNova == null) {
				throw new ResourcesException("Campos de alteração de matrícula preenchidos incorretamente!");
			}
			String linha = br.readLine();
			StringBuilder sb = new StringBuilder();
			boolean primeiraLinha = true;
			while (linha != null) {
				String divideInformacao[] = linha.split(",");
				if (divideInformacao[3].equals(matriculaAtual)) {
					divideInformacao[3] = matriculaNova;
					StringBuilder novaLinha = new StringBuilder();
					for (String informacao : divideInformacao) {
						novaLinha.append(informacao);
						novaLinha.append(",");
					}
					novaLinha.setLength(novaLinha.length() - 1);
					if (!primeiraLinha) {
						sb.append(System.lineSeparator());
					} else {
						primeiraLinha = false;
					}
					sb.append(novaLinha);
				} else {
					if (!primeiraLinha) {
						sb.append(System.lineSeparator());
					} else {
						primeiraLinha = false;
					}
					sb.append(linha);
				}
				linha = br.readLine();
			}
			br.close();
			Files.write(arquivoDeEntrada.toPath(), sb.toString().getBytes());
			LogLogins.alterarMatricula(matriculaAtual, matriculaNova);
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO ALTERAR MATRÍCULA!"));
		} else {
			ProgramaPrincipal.showSuccessMessage(new JLabel("SUCESSO AO ALTERAR MATRÍCULA!"));
		}
		Log.codificarUTF8(pathCadastros);
	}

	/*
	 * Os dois métodos abaixos retornam instâncias de clases que representam dois
	 * dos três tipos de usuário presentes no sistema, isto é, docentes e
	 * estudantes. O funcionamento é igual para ambos, busca-se linha por linha o
	 * identificador (matrícula ou SIAPE) passado por parâmetro e retorna o objeto
	 * instanciado a partir dos dados presentes no próprio arquivo de cadastros.
	 */

	public static Estudante encontrarEstudante(String usuario) {
		String pathCadastros = Log.getPath("logCadastros.txt");
		Log.codificarUTF8(pathCadastros);
		try (BufferedReader br = new BufferedReader(new FileReader(pathCadastros))) {
			String linha = br.readLine();
			while (linha != null) {
				String fields[] = linha.split(",");
				if (fields[1].equals(usuario) || fields[3].equals(usuario)) {
					if (!(fields[5].equals("Estudante"))) {
						throw new ResourcesException("O usuário informado não está cadastrado como Estudante!");
					} else {
						return new Estudante(fields[0], fields[1], sdf.parse(fields[2]), Integer.parseInt(fields[3]),
								Integer.parseInt(fields[4]));
					}
				}
				linha = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (ResourcesException e) {
			e.printStackTrace();
		}
		return new Estudante(LogCadastros.gerarCPF(), "Usuário Padrão", new Date(), 2023, 2023);
	}

	public static Docente encontrarDocente(String usuario) {
		String pathCadastros = Log.getPath("logCadastros.txt");
		Log.codificarUTF8(pathCadastros);
		try (BufferedReader br = new BufferedReader(new FileReader(pathCadastros))) {
			String linha = br.readLine();
			while (linha != null) {
				String fields[] = linha.split(",");
				if (fields[1].equals(usuario) || fields[3].equals(usuario)) {
					if (!(fields[5].equals("Docente"))) {
						throw new ResourcesException("O usuário informado não está cadastrado como Docente!");
					} else {
						return new Docente(fields[0], fields[1], sdf.parse(fields[2]), Integer.parseInt(fields[3]),
								Integer.parseInt(fields[4]));
					}
				}
				linha = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (ResourcesException e) {
			e.printStackTrace();
		}
		return new Docente(LogCadastros.gerarCPF(), "Usuário Padrão", new Date(), 2023, 2023);
	}

	public static String verificarClasseCadastro(String usuario) {
		/*
		 * Esse método busca no arquivo de cadastros pela linha que possui o código
		 * identificador de usuário (matrícula ou SIAPE) igual ao passado por parâmetro
		 * para, então, retornar como String o nome da classe (atribuição) daquele
		 * usuário no sistema.
		 */
		String pathCadastros = Log.getPath("logCadastros.txt");
		Log.codificarUTF8(pathCadastros);
		try (BufferedReader br = new BufferedReader(new FileReader(pathCadastros))) {
			if (usuario.equals("admin")) {
				return "Administrador";
			}
			String linha = br.readLine();
			while (linha != null) {
				String fields[] = linha.split(",");
				if (fields[1].equals(usuario) || fields[3].equals(usuario)) {
					if (fields[5].equals("Estudante")) {
						return "Estudante";
					} else if (fields[5].equals("Docente")) {
						return "Docente";
					}
				}
				linha = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return "Inconclusivo";
	}

	public static String gerarCPF() {
		/*
		 * Esse método tem como finalidade gerar, de forma randômica, um número de CPF
		 * matematicamente válido. Ele cria um objeto da classe Random para gerar
		 * números aleatórios. Em seguida, cria um StringBuilder "cpf" capacidade de 11
		 * caracteres. O método gera 9 números aleatórios e os adiciona a esse objeto
		 * cpf, seguidos pelos caracteres temporários "00". O próximo passo é calcular o
		 * primeiro dígito verificador do CPF com base nos 9 dígitos anteriores. Depois,
		 * calcula-se o segundo dígito verificador do CPF, que leva em consideração os 9
		 * primeiros dígitos e o primeiro dígito verificador. Por fim, o método retorna
		 * o CPF completo como uma string. É importante destacar que isso apenas simula
		 * a geração de um CPF válido, obedecendo à regra matemática usada para o
		 * cálculo dos 2 digitos verificadores.
		 */
		Random random = new Random();
		StringBuilder cpf = new StringBuilder(11);
		for (int i = 0; i < 9; i++) {
			cpf.append(random.nextInt(10));
		}
		cpf.append("00");
		int soma1 = 0;
		for (int i = 0; i < 9; i++) {
			int digito = Character.getNumericValue(cpf.charAt(i));
			/*
			 * Character é a Wrapper Class do tipo primitivo char, tal qual Integer é a
			 * Wrapper Class de números inteiros (int).
			 */
			soma1 += digito * (10 - i);
		}
		int resto1 = soma1 % 11;
		int digitoVerificador1;
		if (resto1 < 2) {
			digitoVerificador1 = 0;
		} else {
			digitoVerificador1 = 11 - resto1;
		}
		cpf.setCharAt(9, Character.forDigit(digitoVerificador1, 10));
		int soma2 = 0;
		for (int i = 0; i < 10; i++) {
			int digito = Character.getNumericValue(cpf.charAt(i));
			soma2 += digito * (11 - i);
		}
		int resto2 = soma2 % 11;
		int digitoVerificador2;
		if (resto2 < 2) {
			digitoVerificador2 = 0;
		} else {
			digitoVerificador2 = 11 - resto2;
		}
		cpf.setCharAt(10, Character.forDigit(digitoVerificador2, 10));
		return cpf.toString();
	}
}