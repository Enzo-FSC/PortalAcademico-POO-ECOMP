package resources;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.ParseException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.JLabel;

import applicationExceptions.ResourcesException;
import gui.ProgramaPrincipal;
import users.Administrador;
import users.Docente;
import users.Estudante;
import users.Pessoa;

public abstract class LogLogins extends Log {
	protected static String defaultPass = new String("4567"); // Senha padrão do sistema
	/*
	 * Para cada usuário que fizer login, o estado (true ou false) atributo será
	 * atualizado conforme necessidade
	 */
	protected static boolean isDefaultPass = false;
	/*
	 * A coleção, da interface Map, chamada mainCollection será utilizada para
	 * armazenar credenciais de login. Ela não é inicializada em sua declaração,
	 * apenas dentro do método fillMap()
	 */
	protected static Map<Pessoa, String> mainCollection;

	private static void fillMap() {
		/*
		 * Inicializa a coleção principal como um LinkedHashMap (mantém ordem de
		 * inserção) para armazenar as informações de login, relacionando Pessoas
		 * (Estudante, Docente ou Administrador) por meio de uma String, representando a
		 * senha de cada usuário
		 */
		mainCollection = new LinkedHashMap<Pessoa, String>();
		// Obtém o caminho do arquivo de logins
		String pathLogin = Log.getPath("logLogins.txt");

		// Cria um objeto File com base no caminho do arquivo
		File arquivoDeEntrada = new File(pathLogin);
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			// Lê a primeira linha do arquivo
			String linha = br.readLine();
			while (linha != null) {
				// Divide a linha em informações usando ';' como delimitador
				String divideInformacao[] = linha.split(";");
				String usuario = divideInformacao[0];
				/*
				 * Verifica a classe de cadastro do usuário e o adiciona à mainCollection com a
				 * informação correspondente
				 */
				if (LogCadastros.verificarClasseCadastro(usuario).equals("Docente")) {
					Docente d = LogCadastros.encontrarDocente(usuario);
					mainCollection.put(d, divideInformacao[1]);
				} else if (LogCadastros.verificarClasseCadastro(usuario).equals("Estudante")) {
					Estudante e = LogCadastros.encontrarEstudante(usuario);
					mainCollection.put(e, divideInformacao[1]);
				} else if (LogCadastros.verificarClasseCadastro(usuario).equals("Administrador")) {
					/*
					 * Cria um objeto Administrador específico se o usuário for um administrador.
					 * Isso ocorre porque só há um usuário com acesso administrador
					 */
					Administrador a = new Administrador("16694492707", "Administrador", sdf.parse("09/10/2023"));
					mainCollection.put(a, divideInformacao[1]);
				} else {
					throw new ResourcesException("Não foi possível identificar a atribuição do usuário no sistema!");
				}
				// Lê a próxima linha do arquivo
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (ParseException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO OPERAR A COLEÇÃO PRINCIPAL!"));
		} else {
			Log.codificarUTF8(pathLogin);
			// Codifica o arquivo em UTF-8
		}
	}

	public static boolean validarLogin(String usuario, char senha[], String chave) {
		fillMap(); // Chama fillMap()
		/*
		 * Se o login do usuário for "admin", testa se a senha é "admin" e retorna o
		 * resultado da verificação. Senão, percorre a mainCollection em busca da Pessoa
		 * com o identificador de usuário igual ao que foi passado por parâmetro. Caso
		 * encontre, testa se as senhas (informada e armazenada no Map) são iguais e
		 * retorna o resultado da verificação. Ademais, muda para true o valor de
		 * isDefaultPass para true ou para false, a depender se a senha é, ou não, a
		 * padrão do sistema (1234)
		 */
		if (usuario.equals("admin")) {
			for (Pessoa p : mainCollection.keySet()) {
				if (p.getNome().equals("Administrador")) {
					StringBuilder senhaInformadaSB = new StringBuilder();
					for (char c : senha) {
						// Monta a string de senha informada iterando sobre o array de char
						senhaInformadaSB.append(c);
					}
					String senhaInformada = senhaInformadaSB.toString();
					return senhaInformada.equals("admin");
				}
			}
		}
		senha = criptografar(senha, chave);
		for (Pessoa p : mainCollection.keySet()) {
			if (String.valueOf(p.getID()).equals(usuario)) {
				/*
				 * Monta uma StringBuilder com cada caractere do array de char "senha" e,
				 * depois, converte para uma String comum (senhaInformada) que, posteriormente,
				 * será comparada com a String senhaCorreta
				 */
				StringBuilder senhaInformadaSB = new StringBuilder();
				for (char c : senha) {
					senhaInformadaSB.append(c);
				}
				String senhaInformada = senhaInformadaSB.toString();
				String senhaCorreta = mainCollection.get(p);
				if (senhaCorreta.equals(defaultPass)) {
					isDefaultPass = true;
				} else {
					isDefaultPass = false;
				}
				return senhaInformada.equals(senhaCorreta);
			}
		}
		return false;
	}

	public static void adicionarCredenciais(Pessoa p) {
		String pathLogin = Log.getPath("logLogins.txt");
		File arquivoDeEntrada = new File(pathLogin);
		boolean gravarCredencial = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformacao[] = linha.split(";");
				if (divideInformacao[0].equals(String.valueOf(p.getID()))) {
					throw new ResourcesException(
							"Usuário já encontra-se cadastrado no sistema. Interrompendo credenciamento!");
				} else {
					gravarCredencial = true;
				}
				linha = br.readLine();
			}
			br.close();
			if (gravarCredencial) {
				BufferedWriter bw = new BufferedWriter(new FileWriter(arquivoDeEntrada, true));
				if (arquivoDeEntrada.length() > 0) {
					bw.newLine();
				}
				/*
				 * Escreve no arquivo de credenciais de login o identificador de acesso e a
				 * senha padrão ("1234" codificada) separados por ';'
				 */
				bw.write(p.getID() + ";" + "4567");
				bw.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ResourcesException e) {
			e.printStackTrace();
		}
		fillMap();
	}

	public static void removerCredenciais(Pessoa p) {
		String pathLogin = Log.getPath("logLogins.txt");
		File arquivoDeEntrada = new File(pathLogin);
		String identificador = String.valueOf(p.getID());
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			StringBuilder novoConteudo = new StringBuilder();
			boolean usuarioEncontrado = false;
			String linha = br.readLine();
			boolean isPrimeiraLinha = true;

			while (linha != null) {
				String divideInformacao[] = linha.split(";");
				if (divideInformacao[0].equals(identificador)) {
					usuarioEncontrado = true;
				} else {
					if (!isPrimeiraLinha) {
						novoConteudo.append(System.lineSeparator());
					}
					novoConteudo.append(linha);
				}
				isPrimeiraLinha = false;
				linha = br.readLine();
			}
			br.close();
			if (usuarioEncontrado) {
				Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
			} else {
				System.out.println("Usuário não encontrado no arquivo de Cadastros");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		fillMap();
	}

	public static boolean getIsDefaultPass() {
		return isDefaultPass;
	}

	public static boolean alterarSenha(String usuario, char senhaAtual[], char senhaNova[], String chave) {
		String pathLogin = Log.getPath("logLogins.txt");
		if (validarLogin(usuario, senhaAtual, chave) && !(Arrays.equals(senhaAtual, senhaNova))) {
			File arquivoDeEntrada = new File(pathLogin);
			StringBuilder novoConteudo = new StringBuilder();
			senhaNova = criptografar(senhaNova, chave);
			try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
				String linha = br.readLine();
				while (linha != null) {
					String divideInformacao[] = linha.split(";");
					if (usuario.equals(divideInformacao[0])) {
						novoConteudo.append(divideInformacao[0]).append(";").append(new String(senhaNova));
					} else {
						novoConteudo.append(linha);
					}
					linha = br.readLine();
					if (linha != null) {
						novoConteudo.append(System.lineSeparator());
					}
				}
				br.close();
				Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
				fillMap();
				return true;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		fillMap();
		return false;
	}

	public static char[] criptografar(char[] senha, String chave) {
		/*
		 * Cifra de Vigenère (adaptada)
		 */
		char[] senhaCriptografada = new char[senha.length];
		int tamanhoChave = chave.length();
		for (int i = 0; i < senha.length; i++) {
			char caractere = senha[i];
			char caractereChave = chave.charAt(i % tamanhoChave);
			/*
			 * Obtém, a cada passo da codificação, o caractere da chave que será usado para
			 * cifrar o caractere correspondente na senha original. O operador "mod" é usado
			 * para garantir que a chave seja "repetida" quando seu comprimento for menor do
			 * que a mensagem
			 */
			if (Character.isLetter(caractere)) {
				char base = Character.isUpperCase(caractere) ? 'A' : 'a';
				/*
				 * É verificado se o caractere da mensagem é uma letra (maiúscula ou minúscula).
				 * Se for uma letra, é determinada a base apropriada ('A' para maiúsculas ou 'a'
				 * para minúsculas) e aplica-se a fórmula da Cifra de Vigenère para calcular o
				 * caractere codificado.
				 */
				char caractereCriptografado = (char) (((caractere + caractereChave - 2 * base) % 26) + base);
				/*
				 * A expressão matemática utilizada para gerar o texto criptografado (caractere
				 * por caractere) é: Caractere Criptografado = (Caractere Original + Caractere
				 * da Chave) % 26. No que se diz respeito a subtrair duas vezes a base e,
				 * depois, somar toda a expressão à própria base, isso garante que o código
				 * funcione corretamente para letras maiúsculas e minúsculas, levando em
				 * consideração a diferença entre os valores ASCII dos caracteres na fórmula
				 */
				senhaCriptografada[i] = caractereCriptografado;
			} else if (Character.isDigit(caractere)) {
				/*
				 * Se o caractere da mensagem for um dígito numérico, realiza-se a adição deste
				 * com 3. Isso não faz parte da Cifra de Vigenère original, implementei apenas
				 * com o intuito de deixar a senha completamente codificada
				 */
				char caractereCriptografado = (char) ((caractere - '0' + 3) % 10 + '0');
				senhaCriptografada[i] = caractereCriptografado;
			} else {
				senhaCriptografada[i] = caractere;
				/*
				 * Para outros caracteres (não-alfabéticos e não-numéricos), o caractere
				 * original é mantido
				 */
			}
		}
		return senhaCriptografada;
	}

	public static void alterarMatricula(String matriculaAtual, String matriculaNova) {
		String pathLogin = Log.getPath("logLogins.txt");
		File arquivoDeEntrada = new File(pathLogin);
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha = br.readLine();
			StringBuilder sb = new StringBuilder();
			boolean primeiraLinha = true;
			while (linha != null) {
				String divideInformacao[] = linha.split(";");
				if (divideInformacao[0].equals(matriculaAtual)) {
					divideInformacao[0] = matriculaNova;
					StringBuilder novaLinha = new StringBuilder();
					for (String informacao : divideInformacao) {
						novaLinha.append(informacao);
						novaLinha.append(";");
					}
					novaLinha.setLength(novaLinha.length() - 1); // Remove a última vírgula
					// Adicione a linha ao novo conteúdo
					if (!primeiraLinha) {
						sb.append(System.lineSeparator());
						/* Adicione uma quebra de linha, exceto para a primeira linha */
					} else {
						primeiraLinha = false;
					}
					sb.append(novaLinha);
				} else {
					// Adicione a linha inalterada ao novo conteúdo
					if (!primeiraLinha) {
						sb.append(System.lineSeparator());
						// Adicione uma quebra de linha, exceto para a primeira linha
					} else {
						primeiraLinha = false;
					}
					sb.append(linha);
				}
				linha = br.readLine();
			}
			// Substitui o conteúdo original do arquivo pelo novo conteúdo
			Files.write(arquivoDeEntrada.toPath(), sb.toString().getBytes());
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO ALTERAR MATRÍCULA!"));
		}
		fillMap();
	}
}