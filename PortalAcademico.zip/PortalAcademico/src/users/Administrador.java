package users;

import java.util.Date;

public class Administrador extends Pessoa {
	public Administrador(String CPF, String name, Date birthDate) {
		super(CPF, name, birthDate);
	}

	@Override
	public String nomeDaClasse() {
		return "Administrador";
	}

	@Override
	public Integer getID() {
		return 0;
	}

	@Override
	public Integer getAnoDeIngresso() {
		return 2023;
	}
}