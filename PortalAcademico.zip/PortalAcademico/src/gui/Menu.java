package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import applicationExceptions.GuiException;
import resources.LogCadastros;
import resources.LogLogins;
import users.Docente;
import users.Estudante;

// Classe que representa a caixa de diálogo de login
class LoginDialog extends JDialog {
	/*
	 * A classe LoginDialog configura a caixa de diálogo que é aberta após o clique
	 * do mouse em qualquer uma das opções de Login do Menu Principal, sendo
	 * possível digitar usuário (matrícula/SIAPE, conforme consta no cadastro, e uma
	 * senha. Após digitar os dados, clicando no botão "Entrar", o usuário é
	 * encaminhado para a devida interface (de acordo com a opção selecionada) caso
	 * os campos tenham sido preenchidos com informações válidas.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField usuarioField = new JTextField(10);
	protected JPasswordField senhaField = new JPasswordField(10);
	protected JButton entrarBotão = new JButton("Entrar");
	protected JButton cancelarBotão = new JButton("Cancelar");
	protected static String usuario = null;

	/*
	 * O atributo estático "usuario" será usado para identificar quem está fazendo
	 * login. Este dado será "encaminhado" para a nova janela aberta (de acordo com
	 * a opção selecionada) por meio do construtor.
	 */
	/*
	 * Construtor da classe LoginDialog. Configura a interface gráfica da caixa de
	 * diálogo de login.
	 */
	public LoginDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(300, 150); // Tamanho da caixa de diálogo é 300px por 150px
		setLocationRelativeTo(parent);
		JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
		panel.add(new JLabel("Usuário:"));
		panel.add(usuarioField);
		panel.add(new JLabel("Senha:"));
		panel.add(senhaField);
		panel.add(entrarBotão);
		panel.add(cancelarBotão);
		entrarBotão.addActionListener(new ActionListener() {
			/*
			 * Verifica-se a atribuição do usuário que está tentando fazer login. Em ambos
			 * os casos, o procedimento é semelhante: instancia-se um objeto da classe
			 * correspondente à atribuição do usuário e, em seguida, é armazenado seu último
			 * nome. Caso o teste do método verificarClasseCadastro() tenha resultado
			 * inconclusivo, isto é, não for possível verificar a atribuição do usuário, é
			 * lançada uma exceção GuiException. Posterior ao teste de atribuição, é feito o
			 * teste do título do botão de login, isto é, qual botão foi pressionado, sendo
			 * que, para os três resultados possíveis, o procedimento é basicamente o mesmo,
			 * mudando, essencialmente, apenas a janela de interface que será aberta em
			 * seguida. Esta só será, de fato, aberta caso o teste de login retorne
			 * verdadeiro, caso contrário, é criada uma segunda janela de diálogo (no caso,
			 * do tipo JOptionPane, que exibe um pop-up de alerta) informado falha na
			 * operação.
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String ultimoNome = null;
					// Verifica a classe do usuário (Estudante, Docente, Administrador)
					if (LogCadastros.verificarClasseCadastro(usuarioField.getText()).equals("Estudante")) {
						Estudante a = LogCadastros.encontrarEstudante(usuarioField.getText());
						String fields[] = a.getNome().split(" ");
						ultimoNome = fields[fields.length - 1];
					} else if (LogCadastros.verificarClasseCadastro(usuarioField.getText()).equals("Docente")) {
						Docente p = LogCadastros.encontrarDocente(usuarioField.getText());
						String fields[] = p.getNome().split(" ");
						ultimoNome = fields[fields.length - 1];
					} else if (LogCadastros.verificarClasseCadastro(usuarioField.getText()).equals("Administrador")) {
						// Autentica o login do Administrador e redireciona para a interface adequada
						if (LogLogins.validarLogin(usuarioField.getText(), senhaField.getPassword(), ultimoNome)) {
							dispose();
							ProgramaPrincipal.adm = new PainelDoAdministrador(usuarioField.getText());
							ProgramaPrincipal.adm.setVisible(true);
							ProgramaPrincipal.menu.setVisible(false);
						} else {
							// Exibe mensagem de erro se a autenticação falhar
							JLabel errorLabel = new JLabel("USUÁRIO E/OU SENHA INVÁLIDOS!");
							ProgramaPrincipal.showErrorMessage(errorLabel);
							throw new GuiException("Usuário e/ou senha digitados são inválidos!");
						}
					} else {
						// Lança exceção se não for possível confirmar a atribuição do usuário
						JLabel errorLabel = new JLabel("USUÁRIO NÃO CADASTRADO OU COM DADOS INVÁLIDOS!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
						throw new GuiException("Não foi possível confirmar a atribuição do usuário no sistema!");
					}
					// Redireciona para as interfaces adequadas com base no título da janela
					if (title.equals("Login como Estudante")) {
						// Autentica o login do Estudante e redireciona para a interface adequada
						if (LogLogins.validarLogin(usuarioField.getText(), senhaField.getPassword(), ultimoNome)) {
							dispose();
							ProgramaPrincipal.est = new PainelDoEstudante(usuarioField.getText());
							ProgramaPrincipal.est.setVisible(true);
							ProgramaPrincipal.menu.setVisible(false);
						} else {
							// Exibe mensagem de erro se a autenticação falhar
							JLabel errorLabel = new JLabel("USUÁRIO E/OU SENHA INVÁLIDOS!");
							ProgramaPrincipal.showErrorMessage(errorLabel);
							throw new GuiException("Usuário e/ou senha digitados são inválidos!");
						}
					} else if (title.equals("Login como Docente")) {
						// Autentica o login do Docente e redireciona para a interface adequada
						if (LogLogins.validarLogin(usuarioField.getText(), senhaField.getPassword(), ultimoNome)) {
							dispose();
							ProgramaPrincipal.doc = new PainelDoDocente(usuarioField.getText());
							ProgramaPrincipal.doc.setVisible(true);
							ProgramaPrincipal.menu.setVisible(false);
						} else {
							// Exibe mensagem de erro se a autenticação falhar
							JLabel errorLabel = new JLabel("USUÁRIO E/OU SENHA INVÁLIDOS!");
							ProgramaPrincipal.showErrorMessage(errorLabel);
							throw new GuiException("Usuário e/ou senha digitados são inválidos!");
						}
					}
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (GuiException e1) {
					e1.printStackTrace();
				}
			}
		});
		cancelarBotão.addActionListener(new ActionListener() {
			/*
			 * ActionListener para o botão "Cancelar". Cancela a operação de login fechando
			 * a janela de diálogo.
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}

		});
		getContentPane().add(panel, BorderLayout.CENTER);
	}

	// Método para obter o nome de usuário
	public static String getUsuarioField() {
		return usuario;
	}
}

// Classe principal que representa o menu inicial
public class Menu extends JFrame implements ActionListener {
	/*
	 * Além dos 3 botões do Menu e do atributo estático menu, que é uma instância de
	 * Menu inicializada como nula, também foi definida uma String que leva ao
	 * caminho relativo do arquivo de imagem para o plano de fundo desta tela da
	 * interface, além do objeto caminhoAbsoluto, da interface Path, que faz a
	 * conversão do caminho relativo para o caminho absoluto desse arquivo. Este
	 * último atributo mencionado é, então, convertido para String e usado no
	 * construtor da classe PlanoDeFundo na instanciação do objeto panel. Dessa
	 * forma, o compilador encontrará a imagem em qualquer computador, sendo que
	 * essa mesma técnica é empregada em todas as outras 3 telas da interface
	 * gráfica.
	 */
	protected static final long serialVersionUID = 1L;
	protected JButton estudanteBotão = new JButton("Estudante");
	protected JButton docenteBotão = new JButton("Docente");
	protected JButton administradorBotão = new JButton("Administrador");
	protected String nomeDoArquivo = "images/fundo.png";

	// Construtor da classe Menu
	public Menu() {
		setTitle("Menu | Portal Acadêmico");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/*
		 * Configura o comportamento da janela ao clicar no botão "Fechar" (do próprio
		 * SO).
		 */
		PlanoDeFundo panel = new PlanoDeFundo(getClass().getClassLoader().getResourceAsStream(nomeDoArquivo));
		/* Coverte a String nomeDoArquivo em uma InputStream */
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 419));
		Dimension buttonSize = new Dimension(200, 50);
		estudanteBotão.setPreferredSize(buttonSize);
		docenteBotão.setPreferredSize(buttonSize);
		administradorBotão.setPreferredSize(buttonSize);
		panel.add(estudanteBotão, panel);
		panel.add(docenteBotão, panel);
		panel.add(administradorBotão, panel);
		add(panel);
		estudanteBotão.addActionListener(this);
		docenteBotão.addActionListener(this);
		administradorBotão.addActionListener(this);
	}

	/*
	 * ActionListener para os botões do menu. Abre uma janela de LoginDialog
	 * baseando-se no nome do botão pressionado.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String buttonText = ((JButton) e.getSource()).getText();
		LoginDialog dialog = new LoginDialog(this, "Login como " + buttonText);
		dialog.setVisible(true);
	}

	// Método para obter o nome de usuário
	public static String getUsuarioField() {
		return LoginDialog.getUsuarioField();
	}
}