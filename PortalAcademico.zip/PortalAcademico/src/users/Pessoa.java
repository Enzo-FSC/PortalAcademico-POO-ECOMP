package users;

import java.util.Date;

import applicationExceptions.UsersException;

public abstract class Pessoa {
	/*
	 * A classe "Pessoa" é uma classe abstrata que serve como base para representar
	 * informações de pessoas. Ela possui três atributos protegidos: "nome", "CPF" e
	 * "dataDeNascimento", que armazenam o nome, CPF e data de nascimento da pessoa,
	 * respectivamente. Esses atributos são inicializados no construtor da classe.
	 * Além de atribuir esses valores aos atributos correspondentes, o construtor
	 * chama o método validadorCPF() para verificar se o CPF fornecido é válido. Se
	 * o CPF não for válido, ele lança uma exceção do tipo UsersException. Também
	 * são definidos métodos públicos para obter os valores dos atributos (getters)
	 * e declara três métodos abstratos que devem ser implementados por classes que
	 * herdam “Pessoa”: nomeDaClasse(), getID() e getAnoDeIngresso().
	 */
	protected String nome;
	protected String CPF;
	protected Date dataDeNascimento;

	public Pessoa(String CPF, String name, Date birthDate) {
		if (validadorCPF(CPF)) {
			this.CPF = CPF;
			this.nome = name;
			this.dataDeNascimento = birthDate;
		}
	}

	public String getCPF() {
		return CPF;
	}

	public String getNome() {
		return nome;
	}

	public Date getDataDeNascimento() {
		return dataDeNascimento;
	}

	public static boolean validadorCPF(String CPF) {
		/*
		 * Implementei esse método validador de CPF no início de setembro em outra
		 * classe Pessoa para um exercício de uma das listas disponibilizadas no Moodle.
		 * Para isso, baseei-me em um artigo, disponível no site da Olimpíada Brasileira
		 * de Matemática (OBMEP), o link para acessar o referido texto estará nas
		 * referências deste relatório. Em resumo, são realizadas várias verificações,
		 * incluindo a contagem de dígitos, a validação do algarismo referente à região
		 * fiscal e a aplicação de regras de validação específicas para os dígitos
		 * verificadores (dois últimos números de um CPF). Se o identificador informado
		 * for inválido, ele lança uma exceção do tipo UsersException. Caso nenhuma
		 * exceção seja lançada, isto indica que o CPF informado é válido.
		 */
		String invalido = "CPF Inválido!";
		String d[] = CPF.split("");
		boolean erro = false;
		/*
		 * Divide a String original (CPF) em 11 Strings independentes, armazenando-as em
		 * um array de Strings "d".
		 */
		try {
			if (!(d.length == 11)) {
				throw new UsersException(invalido);
			}
			// Verificação da região fiscal
			String regiaoFiscalStr = d[8];
			int regiaoFiscal = Integer.parseInt(regiaoFiscalStr);
			if (regiaoFiscal < 0 || regiaoFiscal > 9) {
				throw new UsersException(invalido);
			}
			// Cálculo do primeiro dígito verificador
			int soma1 = 0;
			for (int i = 0; i < 9; i++) {
				int digito = Integer.parseInt(d[i]);
				soma1 += (digito * (10 - i));
			}
			int resto1 = soma1 % 11;
			if (resto1 == 0 || resto1 == 1) {
				if (Integer.parseInt(d[9]) != 0) {
					throw new UsersException(invalido);
				}
			} else {
				if (Integer.parseInt(d[9]) != (11 - resto1)) {
					throw new UsersException(invalido);
				}
			}
			// Cálculo do segundo dígito verificador
			int soma2 = 0;
			for (int i = 1; i < 10; i++) {
				int digito = Integer.parseInt(d[i]);
				soma2 += (digito * (11 - i));
			}
			int resto2 = soma2 % 11;
			if (resto2 == 0 || resto2 == 1) {
				if (Integer.parseInt(d[10]) != 0) {
					throw new UsersException(invalido);
				}
			} else {
				if (Integer.parseInt(d[10]) != (11 - resto2)) {
					throw new UsersException(invalido);
				}
			}
		} catch (NumberFormatException e) {
			erro = true;
			e.printStackTrace();
		} catch (UsersException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			return false;
		} else {
			return true;
		}
	}

	public abstract String nomeDaClasse();

	public abstract Integer getID();

	public abstract Integer getAnoDeIngresso();
}