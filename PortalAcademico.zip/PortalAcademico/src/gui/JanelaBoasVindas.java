package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import resources.LogCadastros;
import resources.LogLogins;

public class JanelaBoasVindas {
	private Font sysFont = null;

	/*
	 * A classe JanelaBoasVindas implementa um pequeno espaço de texto visível no
	 * canto inferior da tela, de forma centralizada, que dá boas-vindas ao usuário
	 * que acabou de realizar login. Esse texto é um JLabel colocado dentro de um
	 * JPanel executado em uma janela de diálogo (JDialog), entretanto, a janela tem
	 * a sua "HUD" oculta, isto é, os controles e a borda da janela (que variam
	 * conforme o SO) são invisíveis, aparentando ter, de fato, apenas um texto
	 * "flutuando" na tela. Caso o retorno do método getIsDefaultPass() for
	 * verdadeiro (o que significa que o usuário ainda está utilizando a senha
	 * padrão do sistema), é emitido um alerta em forma de JOptionPane (configurando
	 * como WARNING MESSAGE). Se o retorno do referido método for falso, o texto de
	 * boas-vindas é imediatamente exibido e permanece assim por 3 segundos (ou
	 * enquanto o usuário não clicar na tela).
	 */
	public JanelaBoasVindas(String usuario) {
		try {
			// Cria a fonta a partir do caminho de InputStream
			sysFont = Font.createFont(Font.TRUETYPE_FONT,
					getClass().getClassLoader().getResourceAsStream("sysfont.otf"));
		} catch (FontFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// Verifica se a senha padrão está sendo utilizada
				if (LogLogins.getIsDefaultPass()) {
					exibirAlertaSenhaPadrao(usuario);
				}
				// Cria a janela de boas-vindas
				criarJanelaBoasVindas(usuario, sysFont);
			}
		});
	}

	// Exibe um alerta se a senha padrão estiver sendo utilizada
	private void exibirAlertaSenhaPadrao(String usuario) {
		if (!(LogCadastros.verificarClasseCadastro(usuario).equals("Administrador"))) {
			JOptionPane.showMessageDialog(null, "VOCÊ ESTÁ USANDO A SENHA PADRÃO. POR FAVOR, ALTERE SUA SENHA!",
					"SENHA PADRÃO DETECTADA", JOptionPane.WARNING_MESSAGE);
		}
	}

	// Cria a janela de boas-vindas
	public static void criarJanelaBoasVindas(String usuario, Font fonte) {
		JDialog janela = new JDialog();
		janela.setUndecorated(true); // Torna a janela sem borda e controles
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(192, 192, 192));
		/*
		 * A cor de fundo definida para o JPanel é exatamente o mesmo tom de cinza da
		 * imagem de fundo das interfaces.
		 */
		janela.add(panel);
		JLabel label = null;
		/*
		 * Aqui verifica-se a atribuição do usuário (se é Docente, Estudante ou
		 * Administrador), exibindo, assim, uma mensagem personalizada para cada usuário
		 * que realiza login.
		 */
		if (LogCadastros.verificarClasseCadastro(usuario).equals("Docente")) {
			label = new JLabel("Boas-vindas, "
					+ new String(LogCadastros.encontrarDocente(usuario).getNome().getBytes(), StandardCharsets.UTF_8)
					+ "!");
		} else if (LogCadastros.verificarClasseCadastro(usuario).equals("Estudante")) {
			label = new JLabel("Boas-vindas, "
					+ new String(LogCadastros.encontrarEstudante(usuario).getNome().getBytes(), StandardCharsets.UTF_8)
					+ "!");
		} else if (usuario.equals("admin")) {
			label = new JLabel("Boas-vindas, Administrador!");
		}
		label.setHorizontalAlignment(SwingConstants.CENTER);
		/* Baixei uma fonte e inseri nos arquivos do projeto. */
		fonte = fonte.deriveFont(Font.PLAIN, 22);
		/*
		 * Define o tamanho da fonte como 25. Creio que seja invariável conforme o SO em
		 * uso, todos os meus testes foram feitos no Windows 11.
		 */
		label.setFont(fonte);
		panel.add(label, BorderLayout.CENTER);
		janela.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		janela.setSize(550, 50); // Define o tamanho da janela.
		janela.setLocationRelativeTo(null); // Centraliza a janela na tela
		janela.setLocation(495, 590);
		/*
		 * Define a localização da janela (parte inferior da tela, centralizada
		 * horizontalmente).
		 */
		janela.setVisible(true);
		/*
		 * A própria biblioteca Swing disponibiliza uma classe Timer que, como o nome
		 * indica, "dispara" um (ou mais) ActionEvents por intervalos de tempo
		 * especificados. Nesse caso, a ação é mostrar a janela de boas vindas, que fica
		 * visível por 3 segundos (ou 3000 milissegundos). O objeto timer é configurado
		 * para nunca se repetir.
		 */
		javax.swing.Timer timer = new javax.swing.Timer(3000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				janela.dispose(); // Fecha a janela após 3 segundos
			}
		});
		timer.setRepeats(false);
		timer.start();
	}
}