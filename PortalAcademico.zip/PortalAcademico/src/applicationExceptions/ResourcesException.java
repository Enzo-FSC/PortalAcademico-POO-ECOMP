package applicationExceptions;

public class ResourcesException extends Exception {
	/*
	 * Classe ResourcesException estende a classe Exception (necessita ser tratada,
	 * diferente da RuntimeException)
	 */
	private static final long serialVersionUID = 1L;

	public ResourcesException(String msg) {
		/*
		 * Construtor envia para a super-classe a mensagem entre aspas + a mensagem
		 * passada por parâmetro
		 */
		super("Resources Exception Throwed: " + msg);
	}
}