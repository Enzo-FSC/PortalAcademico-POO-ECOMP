package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import applicationExceptions.GuiException;
import resources.Disciplina;
import resources.LogCadastros;
import resources.LogDisciplinas;
import users.Estudante;

class ListarDisciplinasEstudante {
	/*
	 * A classe ListarDisciplinasEstudante tem a finalidade de exibir uma lista
	 * (tabela) das disciplinas em que um estudante está matriculado. É obtida a
	 * lista de disciplinas através do método listarDisciplinasAluno(), utilizando o
	 * nome de usuário passado como parâmetro no construtor da classe. São definidos
	 * os nomes das colunas da tabela como "Nome," "Código," e "Docente," e criada
	 * uma matriz bidimensional chamada "data" para armazenar os dados das
	 * disciplinas. Um loop (for each) itera sobre a lista de disciplinas obtidas,
	 * extraindo o nome, código e nome do docente para cada disciplina e preenchendo
	 * a matriz "data" com esses valores. É utilizada a classe JTable para criar uma
	 * tabela com os dados da matriz e os nomes das colunas. A tabela é colocada
	 * dentro de um painel com barra de rolagem, usando a classe JScrollPane. Uma
	 * janela de diálogo da classe JDialog é usada para exibir a tabela, com o
	 * título definido como "Lista de Disciplinas Matriculadas - " seguido do nome
	 * do estudante.
	 */
	public ListarDisciplinasEstudante(String usuario) {
		StringBuilder dialogText = new StringBuilder();
		dialogText.append("Nome\t\t\tCódigo\t\t\tProfessor\n");
		List<Disciplina> listaAux = LogDisciplinas.listarDisciplinasEstudante(usuario);
		if (listaAux.isEmpty() || listaAux == null) {
			ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO ESTÁ MATRICULADO EM NENHUMA DISCIPLINA!"));
		} else {
			String[] columnNames = { "Nome", "Código", "Docente" };
			String[][] data = new String[listaAux.size()][3];
			/*
			 * A dimensão de linhas da matriz bidimensional tem tamanho relativo ao tamanho
			 * da lista auxiliar.
			 */
			int i = 0;
			for (Disciplina d : listaAux) {
				String nome = d.getNomeDaDisciplina();
				String codigo = d.getId();
				String docente = d.getDocenteEncarregado().getNome();
				data[i][0] = nome;
				data[i][1] = codigo;
				data[i][2] = docente;
				i++;
			}
			JTable table = new JTable(data, columnNames);
			JScrollPane scrollPane = new JScrollPane(table);
			JDialog dialog = new JDialog();
			dialog.setTitle(
					"Lista de Disciplinas Matriculadas - " + LogCadastros.encontrarEstudante(usuario).getNome());
			dialog.setSize(750, 450); // Tamanho 750px por 450px
			dialog.setLocationRelativeTo(null);
			dialog.add(scrollPane);
			dialog.setVisible(true);
		}
	}
}

class BuscarDisciplinaEstudante extends JDialog {
	/*
	 * A classe "BuscarDisciplinaEstudante" implementa uma janela de diálogo que
	 * permite aos estudantes buscar informações sobre uma disciplina específica.
	 * Ela estende a classe "JDialog" e possui dois botões, um campo de texto para
	 * inserir o código da disciplina e uma variável para armazenar o nome de
	 * usuário do estudante. Quando o botão "Confirmar" é clicado, o método buscar()
	 * é chamado com o código da disciplina inserido no campo de texto. Se a
	 * disciplina for encontrada, uma nova janela (TabelaBuscaCadeiraEstudante) é
	 * aberta para exibir as informações da disciplina. Caso contrário, exibe uma
	 * mensagem de erro em uma caixa de diálogo.
	 */
	private static final long serialVersionUID = 1L;
	private JButton buscarBotão = new JButton("Buscar");
	private JButton cancelarBotão = new JButton("Cancelar");
	private JTextField cadeiraField = new JTextField(10);
	private String usuario = null;

	public BuscarDisciplinaEstudante(JFrame parent, String title, String usuario) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);
		this.usuario = usuario;

		JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
		cadeiraField = new JTextField(10);
		buscarBotão = new JButton("Confirmar");
		cancelarBotão = new JButton("Cancelar");

		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(cadeiraField);
		panel.add(buscarBotão);
		panel.add(cancelarBotão);

		buscarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Disciplina d = buscar(cadeiraField.getText());
				if (d == null) {
					JLabel errorLabel = new JLabel("ERRO AO BUSCAR DISCIPLINA!");
					ProgramaPrincipal.showErrorMessage(errorLabel);
				} else {
					dispose();
					new TabelaBuscaCadeiraEstudante(parent, "Exibindo " + d.getNomeDaDisciplina(), d, usuario);
				}
			}
		});

		cancelarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}

	public Disciplina buscar(String codigoDisciplina) {
		/*
		 * O método recebe o código da disciplina a ser procurada, obtém uma lista de
		 * disciplinas associadas ao estudante com base no nome de usuário e itera sobre
		 * ela (loop for each), verificando se a disciplina com o código fornecido está
		 * na lista. Se encontrada, a disciplina é retornada. Caso haja uma disciplina
		 * vazia (null), é lançada uma exceção GuiException, já que não é possível
		 * existir disciplina sem nome, código e professor. No caso da disciplina
		 * simplesmente não ser encontrada, retorna nulo após informar o erro (println)
		 * em console.
		 */
		try {
			List<Disciplina> listaDisciplinas = LogDisciplinas.listarDisciplinasEstudante(usuario);
			if (listaDisciplinas.isEmpty() || listaDisciplinas == null) {
				throw new GuiException("Erro ao listar disciplinas vinculadas ao estudante!");
			} else {
				for (Disciplina d : listaDisciplinas) {
					if (d == null) {
						throw new GuiException("Erro inesperado ao buscar disciplina!");
					}
					if (d.getId().equals(codigoDisciplina)) {
						return d;
					}
				}
				throw new GuiException("Disciplina não existe ou estudante não está matriculado nela!");
			}
		} catch (GuiException e) {
			e.printStackTrace();
		}
		return null;
	}
}

class TabelaBuscaCadeiraEstudante extends JDialog {
	/*
	 * Funcionamento semelhante ao da classe ListarDisciplinasEstudante, entretanto,
	 * a tabela só possui uma linha de dados, e as colunas são preenchidas con
	 * informação de nome da disciplina, código e a nota média do estudante nessa
	 * cadeira (depende da publicação manual das notas por parte do docente).
	 */
	private static final long serialVersionUID = 1L;

	public TabelaBuscaCadeiraEstudante(JFrame parent, String title, Disciplina d, String usuario) {
		super(parent, title, true);
		setSize(900, 77);
		setLocationRelativeTo(parent);
		StringBuilder dialogText = new StringBuilder();
		dialogText.append("Nome\t\t\tCódigo\t\t\tNota\n");
		Estudante a = LogCadastros.encontrarEstudante(usuario);
		String[] columnNames = { "Nome", "Código", "Nota" };
		String[][] data = new String[1][3];
		data[0][0] = d.getNomeDaDisciplina();
		data[0][1] = d.getId();
		data[0][2] = String.valueOf(LogDisciplinas.notaPorEstudanteEmDisciplina(a, d));
		JTable table = new JTable(data, columnNames);
		JScrollPane scrollPane = new JScrollPane(table);
		JDialog dialog = new JDialog();
		dialog.setTitle("Busca por Disciplina");
		dialog.setSize(900, 77);
		dialog.setLocationRelativeTo(null);
		dialog.add(scrollPane);
		dialog.setVisible(true);
	}
}

class MediaSemestralEstudante {
	/*
	 * A classe MediaSemestralEstudante desempenha a função de exibir a média
	 * semestral de um estudante em suas disciplinas. Ela começa obtendo uma lista
	 * de disciplinas em que o estudante está matriculado, utilizando o método
	 * listarDisciplinasAluno() e o nome de usuário fornecido como argumento no
	 * construtor da classe. A tabela resultante tem colunas com os cabeçalhos
	 * "Nome," "Código," e "Nota". Os dados das disciplinas são armazenados em uma
	 * matriz bidimensional chamada "data". Um loop for each percorre a lista de
	 * disciplinas, extraindo o nome, código e nota média de cada disciplina e
	 * preenchendo a matriz "data" com esses valores. A classe faz uso de JTable
	 * para criar a tabela que exibe os dados da matriz e os nomes das colunas. Essa
	 * tabela é alocada em um painel de rolagem (JScrollPane), permitindo que o
	 * usuário veja todas as informações. Por fim, uma janela de diálogo da classe
	 * JDialog é utilizada para apresentar a tabela ao usuário, cujo título é
	 * definido como "Média Semestral - " seguido do nome do estudante.
	 */
	public MediaSemestralEstudante(String usuario) {
		StringBuilder dialogText = new StringBuilder();
		dialogText.append("Nome\t\t\tCódigo\t\t\tNota\n");
		List<Disciplina> listaAux = LogDisciplinas.listarDisciplinasEstudante(usuario);
		if (listaAux.isEmpty() || listaAux == null) {
			ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO ESTÁ MATRICULADO EM NENHUMA DISCIPLINA!"));
		} else {
			String[] columnNames = { "Nome", "Código", "Nota" };
			String[][] data = new String[listaAux.size() + 1][3];
			Double mediaSemestral = 0.0;
			int i = 0;
			for (Disciplina d : listaAux) {
				String nome = d.getNomeDaDisciplina();
				String codigo = d.getId();
				String notaMedia = String.valueOf(
						LogDisciplinas.notaPorEstudanteEmDisciplina(LogCadastros.encontrarEstudante(usuario), d));
				data[i][0] = nome;
				data[i][1] = codigo;
				data[i][2] = notaMedia;
				mediaSemestral += LogDisciplinas.notaPorEstudanteEmDisciplina(LogCadastros.encontrarEstudante(usuario),
						d);
				i++;
			}
			mediaSemestral = mediaSemestral / i;
			data[listaAux.size()][0] = "MEDIA SEMESTRAL";
			data[listaAux.size()][1] = "";
			data[listaAux.size()][2] = String.valueOf(mediaSemestral);
			JTable table = new JTable(data, columnNames);
			JScrollPane scrollPane = new JScrollPane(table);
			JDialog dialog = new JDialog();
			dialog.setTitle("Media Semestral - " + LogCadastros.encontrarEstudante(usuario).getNome());
			dialog.setSize(750, 450);
			dialog.setLocationRelativeTo(null);
			dialog.add(scrollPane);
			dialog.setVisible(true);
		}
	}
}

class SolicitarMatricula extends JDialog {
	/*
	 * A classe SolicitarMatricula tem a finalidade de criar uma janela de diálogo
	 * que permite a um estudante solicitar a matrícula em uma disciplina. Ela
	 * estende a classe JDialog e inclui um campo de texto para inserir o código da
	 * disciplina desejada, um botão "Confirmar" para enviar a solicitação e um
	 * botão "Cancelar" para fechar a janela. Quando o botão "Confirmar" é acionado,
	 * a classe chama o método solicitarMatricula(), passando usuário e código por
	 * parâmetro, e verifica se a solicitação foi bem-sucedida e exibe uma mensagem
	 * de erro em caso contrário. A janela é fechada após a ação ser concluída. A
	 * lógica por trás da solicitação é desenvolvida na classe LogDisciplinas, que
	 * faz manipulação de arquivos.
	 */
	private static final long serialVersionUID = 1L;
	private JButton solicitarBotão = new JButton("Buscar");
	private JButton cancelarBotão = new JButton("Cancelar");
	private JTextField cadeiraField = new JTextField(10);

	public SolicitarMatricula(JFrame parent, String title, String usuario) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
		cadeiraField = new JTextField(10);
		solicitarBotão = new JButton("Confirmar");
		cancelarBotão = new JButton("Cancelar");

		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(cadeiraField);
		panel.add(solicitarBotão);
		panel.add(cancelarBotão);

		solicitarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					List<Disciplina> aux = new ArrayList<>();
					aux = LogDisciplinas.listarDisciplinasEstudante(usuario);
					for (Disciplina d : aux) {
						if (cadeiraField.getText().equals(d.getId())) {
							JLabel errorLabel = new JLabel("VOCÊ JÁ ESTÁ MATRICULADO NESTA DISCIPLINA!");
							ProgramaPrincipal.showErrorMessage(errorLabel);
							throw new GuiException("Estudante já matriculado na disciplina!");
						}
					}
					if (!(LogDisciplinas.solicitarMatricula(usuario, cadeiraField.getText()))) {
						JLabel errorLabel = new JLabel("ERRO AO SOLICITAR MATRÍCULA!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
						throw new GuiException("Erro na solicitação de matrícula!");
					} else {
						JLabel successLabel = new JLabel("SUCESSO AO SOLICITAR MATRÍCULA!");
						ProgramaPrincipal.showSuccessMessage(successLabel);
						dispose();
					}
				} catch (GuiException e1) {
					e1.printStackTrace();
				}
			}
		});

		cancelarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

public class PainelDoEstudante extends JFrame implements ActionListener {
	/*
	 * Assim como na interface do menu, a classe PainelDoEstudante tem como
	 * atributos alguns botões, além de um atributo estático da classe String que
	 * armazena o identificador do usuário, passado por parâmetro ao construtor
	 * quando é instanciado um novo objeto da classe PainelDoEstudante na classe
	 * LoginDialog (no Menu). Além disso, também aplica a técnica de converter
	 * caminho relativo em absoluto e utiliza isso para impor um plano de fundo
	 * (diferente daquele visto no Menu).
	 */
	protected static final long serialVersionUID = 1L;
	protected JButton buscarDisciplinaBotão = new JButton("Buscar por Disciplina");
	protected JButton listarDisciplinasBotão = new JButton("Listar Disciplinas");
	protected JButton visualizarNotaMediaBotão = new JButton("Visualizar Média Semestral");
	protected JButton solicitarMatriculaBotão = new JButton("Solicitar Matrícula");
	protected JButton alterarSenhaBotão = new JButton("Alterar Senha");
	protected JButton sairBotão = new JButton("Sair");
	protected static String usuario = null;
	protected String nomeDoArquivo = "images/fundoEstudante.png";

	public PainelDoEstudante(String usuario) {
		PainelDoEstudante.usuario = usuario;
		setTitle("Painel do Estudante | Portal Acadêmico");
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximiza o tamanho da janela com relação à resolução do monitor.
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/*
		 * Configura o comportamento da janela ao clicar no botão "Fechar" (do próprio
		 * SO).
		 */
		PlanoDeFundo panel = new PlanoDeFundo(getClass().getClassLoader().getResourceAsStream(nomeDoArquivo));
		/*
		 * Adicionar um painel com a imagem de fundo usando uma InputStream para obter o
		 * caminho
		 */
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 419));
		/*
		 * O FlowLayout comporta os botões centralizados em relação à imagem de fundo.
		 */
		Dimension buttonSize = new Dimension(200, 50);
		// Define o tamanho preferido para os botões
		buscarDisciplinaBotão.setPreferredSize(buttonSize);
		listarDisciplinasBotão.setPreferredSize(buttonSize);
		visualizarNotaMediaBotão.setPreferredSize(buttonSize);
		solicitarMatriculaBotão.setPreferredSize(buttonSize);
		alterarSenhaBotão.setPreferredSize(buttonSize);
		sairBotão.setPreferredSize(buttonSize);

		// Adiciona os botões ao painel
		panel.add(buscarDisciplinaBotão);
		panel.add(listarDisciplinasBotão);
		panel.add(visualizarNotaMediaBotão);
		panel.add(solicitarMatriculaBotão);
		panel.add(alterarSenhaBotão);
		panel.add(sairBotão);

		// Adiciona o painel ao JFrame
		add(panel);

		/*
		 * Criando um JPanel que organiza (por meio do GridLayout) os botões em 2 linhas
		 * e 2 colunas, com espaçamento horizontal e vertical de 20px entre si
		 */
		JPanel panel1 = new JPanel(new GridLayout(2, 3, 20, 20));
		// Define cor de fundo para o JPanel (mesmo tom de cinza do background)
		panel1.setBackground(new Color(192, 192, 192));
		/*
		 * A cor de fundo definida para o JPanel é exatamente o mesmo tom de cinza da
		 * imagem de fundo das interfaces.
		 */

		// Adiciona os botões ao JPanel
		panel1.add(buscarDisciplinaBotão);
		panel1.add(listarDisciplinasBotão);
		panel1.add(visualizarNotaMediaBotão);
		panel1.add(solicitarMatriculaBotão);
		panel1.add(alterarSenhaBotão);
		panel1.add(sairBotão);

		// Adiciona o JPanel ao painel principal
		panel.add(panel1);

		// Adiciona ActionListener aos botões
		buscarDisciplinaBotão.addActionListener(this);
		listarDisciplinasBotão.addActionListener(this);
		visualizarNotaMediaBotão.addActionListener(this);
		solicitarMatriculaBotão.addActionListener(this);
		alterarSenhaBotão.addActionListener(this);
		sairBotão.addActionListener(this);
		new JanelaBoasVindas(usuario);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		/*
		 * Dependendo do texto do botão pressionado, o método realiza ações específicas.
		 * Se o botão tiver o texto "Sair", o programa é encerrado. Se o texto for
		 * "Listar Disciplinas", uma instância de ListarDisciplinasEstudante é criada,
		 * abrindo a tabela implementada na referida classe (por isso não é necessário
		 * utilizar um método para configurar a visibilidade do objeto, isso é feito na
		 * própria classe). Se o texto for "Visualizar Média Semestral", uma instância
		 * de MediaSemestralEstudante é criada, porém, segue a mesma lógica de
		 * ListarDisciplinasEstudante, a própria classe torna a tabela visível. Se o
		 * texto for "Solicitar Matrícula", uma instância de SolicitarMatricula é
		 * criada, já se o texto for "Alterar Senha", será criada uma instância de
		 * AlterarSenha, agora, se o texto for "Buscar por Disciplina", uma instância de
		 * BuscarDisciplinaEstudante, as três são configuradas como visíveis.
		 */
		String buttonText = ((JButton) e.getSource()).getText(); // Cria String que recebe o nome do botão pressionado
		if (buttonText.equals("Sair")) {
			setVisible(false);
			ProgramaPrincipal.menu.setVisible(true);
		} else if (buttonText.equals("Listar Disciplinas")) {
			if (LogDisciplinas.listarDisciplinasEstudante(usuario) == null
					|| LogDisciplinas.listarDisciplinasEstudante(usuario).isEmpty()) {
				ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO ESTÁ MATRICULADO EM NENHUMA DISCIPLINA!"));
			} else {
				@SuppressWarnings("unused")
				ListarDisciplinasEstudante dialog = new ListarDisciplinasEstudante(usuario);
			}
		} else if (buttonText.equals("Buscar por Disciplina")) {
			if (LogDisciplinas.listarDisciplinasEstudante(usuario) == null
					|| LogDisciplinas.listarDisciplinasEstudante(usuario).isEmpty()) {
				ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO ESTÁ MATRICULADO EM NENHUMA DISCIPLINA!"));
			} else {
				BuscarDisciplinaEstudante dialog = new BuscarDisciplinaEstudante(this, buttonText, usuario);
				dialog.setVisible(true);
			}
		} else if (buttonText.equals("Visualizar Média Semestral")) {
			if (LogDisciplinas.listarDisciplinasEstudante(usuario) == null
					|| LogDisciplinas.listarDisciplinasEstudante(usuario).isEmpty()) {
				ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO ESTÁ MATRICULADO EM NENHUMA DISCIPLINA!"));
			} else {
				@SuppressWarnings("unused")
				MediaSemestralEstudante dialog = new MediaSemestralEstudante(usuario);
			}
		} else if (buttonText.equals("Solicitar Matrícula")) {
			SolicitarMatricula dialog = new SolicitarMatricula(this, buttonText, usuario);
			dialog.setVisible(true);
		} else if (buttonText.equals("Alterar Senha")) {
			AlterarSenha dialog = new AlterarSenha(this, buttonText, usuario);
			dialog.setVisible(true);
		}
	}
}