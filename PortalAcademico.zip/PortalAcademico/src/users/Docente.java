package users;

import java.util.Date;

public class Docente extends Pessoa {
	protected Integer siape;
	protected Integer anoDeIngresso;

	public Docente(String CPF, String name, Date birthDate, Integer siape, Integer anoDeIngresso) {
		super(CPF, name, birthDate);
		if (validadorCPF(CPF)) {
			this.siape = siape;
			this.anoDeIngresso = anoDeIngresso;
		}
	}

	public Integer getSiape() {
		return siape;
	}

	@Override
	public Integer getAnoDeIngresso() {
		return anoDeIngresso;
	}

	@Override
	public String nomeDaClasse() {
		return "Docente";
	}

	@Override
	public Integer getID() {
		return getSiape();
	}
}