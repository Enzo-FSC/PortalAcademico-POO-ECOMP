package resources;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;

import gui.ProgramaPrincipal;

public abstract class Log {
	protected static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); // Objeto formatador de data
	// Caminhos "nativos" do sistema para os arquivos de recursos
	private static String pathDiretorio = "src//resourceFiles";
	private static String pathCadastros = "src//resourceFiles//logCadastros.txt";
	private static String pathDisciplinasDocente = "src//resourceFiles//logDisciplinasDocente.txt";
	private static String pathDisciplinasEstudante = "src//resourceFiles//logDisciplinasEstudante.txt";
	private static String pathNotasPorEstudante = "src//resourceFiles//logNotasPorEstudante.txt";
	private static String pathLogins = "src//resourceFiles//logLogins.txt";

	/*
	 * ArrayList que armazena os caminhos dos arquivos do sistema em formato de
	 * objetos de tipo String
	 */
	private static List<String> pathsCollection;

	/*
	 * Método privado para preencher a lista pathsCollection com caminhos de
	 * arquivos
	 */
	private static void pathsCollectionFill() {
		if (verificarDiretorio(pathDiretorio)) {
			/*
			 * Inicializa o ArrayList com uma capacidade inicial (consequentemente, também é
			 * a capacidade máxima) de 5 objetos
			 */
			pathsCollection = new ArrayList<>(5);
			/*
			 * Adiciona caminhos absolutos (convertidos a partir do caminho relativo) dos
			 * arquivos à lista
			 */
			pathsCollection.add(Paths.get(pathCadastros).toAbsolutePath().toString());
			pathsCollection.add(Paths.get(pathDisciplinasDocente).toAbsolutePath().toString());
			pathsCollection.add(Paths.get(pathDisciplinasEstudante).toAbsolutePath().toString());
			pathsCollection.add(Paths.get(pathNotasPorEstudante).toAbsolutePath().toString());
			pathsCollection.add(Paths.get(pathLogins).toAbsolutePath().toString());
		}
	}

	public static boolean verificarDiretorio(String caminhoDiretorio) {
		/*
		 * Verifica se 'src/resourceFiles' existe no diretório onde o software está
		 * sendo executado
		 */
		File diretorio = new File(caminhoDiretorio);
		return diretorio.exists() && diretorio.isDirectory();
	}

	/*
	 * Método estático para obter o caminho do arquivo com base no nome do arquivo
	 * fornecido
	 */
	public static String getPath(String nomeDoArquivo) {
		// Preenche a lista de caminhos
		pathsCollectionFill();
		// Verifica o nome do arquivo e retorna o caminho correspondente
		if (nomeDoArquivo.equals("logCadastros.txt")) {
			return pathsCollection.get(0);
		} else if (nomeDoArquivo.equals("logDisciplinasDocente.txt")) {
			return pathsCollection.get(1);
		} else if (nomeDoArquivo.equals("logDisciplinasEstudante.txt")) {
			return pathsCollection.get(2);
		} else if (nomeDoArquivo.equals("logNotasPorEstudante.txt")) {
			return pathsCollection.get(3);
		} else if (nomeDoArquivo.equals("logLogins.txt")) {
			return pathsCollection.get(4);
		} else {
			// Retorna nulo se o nome do arquivo não for reconhecido
			return null;
		}
	}

	public static void codificarUTF8(String caminhoArquivo) {
		boolean erro = false;
		try {
			// Lê o conteúdo do arquivo
			File arquivoDeEntrada = new File(caminhoArquivo);
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(new FileInputStream(arquivoDeEntrada), StandardCharsets.UTF_8))) {
				StringBuilder conteudo = new StringBuilder();
				String linha = br.readLine();
				while (linha != null) {
					conteudo.append(linha);
					linha = br.readLine();
					if (linha != null) {
						conteudo.append(System.lineSeparator());
					}
				}
				// Escrever o conteúdo do arquivo usando a codificação UTF-8
				try (BufferedWriter bw = new BufferedWriter(
						new OutputStreamWriter(new FileOutputStream(arquivoDeEntrada), StandardCharsets.UTF_8))) {
					bw.write(conteudo.toString());
				}
			}
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(
					new JLabel("ERRO CRÍTICO AO CODIFICAR ARQUIVOS EM UTF-8! ENCERRANDO A APLICAÇÃO!"));
			System.exit(0);
		}
	}

	public static void setNovosCaminhos(List<File> lista, String diretorioNovo) {
		boolean erro = false;
		for (File f : lista) {
			if (!erro) {
				if (f == null) {
					// Se encontra um arquivo nulo, interrompe o for
					erro = true;
					break;
				}
				if (f.getName().equals("logCadastros.txt")) {
					pathCadastros = f.getAbsolutePath().toString();
				} else if (f.getName().equals("logDisciplinasDocente.txt")) {
					pathDisciplinasDocente = f.getAbsolutePath().toString();
				} else if (f.getName().equals("logDisciplinasEstudante.txt")) {
					pathDisciplinasEstudante = f.getAbsolutePath().toString();
				} else if (f.getName().equals("logLogins.txt")) {
					pathLogins = f.getAbsolutePath().toString();
				} else if (f.getName().equals("logNotasPorEstudante.txt")) {
					pathNotasPorEstudante = f.getAbsolutePath().toString();
				}
			}
		}
		if (!erro) {
			File f = new File(diretorioNovo);
			if (f.exists()) {
				// O caminho de diretório só é alterado caso o caminho exista
				pathDiretorio = diretorioNovo;
			} else {
				ProgramaPrincipal.showErrorMessage(
						new JLabel("ERRO CRÍTICO AO GERAR DIRETÓRIO DE ARQUIVOS! ENCERRANDO A APLICAÇÃO!"));
				System.exit(0);
			}
		} else {
			ProgramaPrincipal.showErrorMessage(
					new JLabel("ERRO CRÍTICO AO GERAR CAMINHOS DE ARQUIVOS! ENCERRANDO A APLICAÇÃO!"));
			System.exit(0);
		}
	}
}