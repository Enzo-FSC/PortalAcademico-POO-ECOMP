package gui;

import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

class PlanoDeFundo extends JPanel {
	/*
	 * A classe PlanoDeFundo, que extende JPanel, foi criada apenas para que fosse
	 * possível impor uma imagem como plano de fundo do programa, sendo que, em cada
	 * tela da interface, a imagem é diferente.
	 */
	protected static final long serialVersionUID = 1L;
	// Armazena a imagem de plano de fundo.
	protected Image backgroundImage;

	// Construtor da classe que recebe o caminho da imagem como parâmetro.
	public PlanoDeFundo(InputStream imageStream) {
		try {
			backgroundImage = ImageIO.read(imageStream);
		} catch (IOException e) {
			ProgramaPrincipal.showErrorMessage(
					new JLabel("ERRO INESPERADO AO CARREGAR PLANO DE FUNDO! ENCERRANDO A APLICAÇÃO!"));
			e.printStackTrace();
			System.exit(0);
		}
	}

	// Sobrescreve o método paintComponent para desenhar o plano de fundo.
	@Override
	protected void paintComponent(Graphics g) {
		/*
		 * Chama o método paintComponent da superclasse para garantir o comportamento
		 * padrão
		 */
		super.paintComponent(g);
		// Verifica se a imagem de plano de fundo está carregada.
		if (backgroundImage != null) {
			/*
			 * Desenha a imagem de plano de fundo, ajustando seu tamanho para preencher o
			 * JPanel.
			 */
			g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
		}
	}
}