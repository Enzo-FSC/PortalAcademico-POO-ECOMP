package users;

import java.util.Date;

public class Estudante extends Pessoa {
	protected Integer matricula; // Wrapper Class Integer Matrícula do Estudante
	protected Integer anoDeIngresso; // Wrapper Class Integer Ano de Ingresso do Estudante

	public Estudante(String CPF, String nome, Date dataDeNascimento, Integer matricula, Integer anoDeIngresso) {
		super(CPF, nome, dataDeNascimento);
		if (validadorCPF(CPF)) {
			this.matricula = matricula;
			this.anoDeIngresso = anoDeIngresso;
		}
	}

	public Integer getMatricula() {
		return matricula;
	}

	@Override
	public Integer getAnoDeIngresso() {
		return anoDeIngresso;
	}

	@Override
	public String nomeDaClasse() {
		return "Estudante";
	}

	@Override
	public Integer getID() {
		return getMatricula();
	}
}