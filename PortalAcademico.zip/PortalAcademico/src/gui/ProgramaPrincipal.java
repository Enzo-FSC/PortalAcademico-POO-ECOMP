package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

import applicationExceptions.GuiException;
import resources.Log;

/*Classe abstrata ProgramaPrincipal serve como ponto de entrada principal para o programa, abrindo a interface Menu no seu método main*/
public abstract class ProgramaPrincipal {
	/*
	 * São declarados atributos protegidos e estáticos para armazenar, de forma
	 * única, instâncias da interface. Desse modo, é possível executar o programa
	 * principal, o que cria uma instância da interface Menu, e navegar entre as
	 * três diferentes interfaces de usuários do sistema, isto é, é possível logar
	 * como Administrador, clicar em "Sair" e voltar ao Menu, ao invés de
	 * simplesmente encerrar por completo a execução do programa
	 */
	protected static Menu menu = null;
	protected static PainelDoEstudante est = null;
	protected static PainelDoDocente doc = null;
	protected static PainelDoAdministrador adm = null;

	// Método principal que é chamado ao iniciar o programa
	public static void main(String[] args) {
		/*
		 * Executa a criação e exibição da interface gráfica Swing em uma thread
		 * separada
		 */
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				// Cria uma instância da classe de interface Menu e a torna visível
				menu = new Menu();
				menu.setVisible(true);
				/*
				 * Aqui é montado um caminho de diretório baseando-se na pasta onde o programa
				 * está sendo executado, adicionado do diretório "src" e do diretório
				 * "resourceFiles" (que fica dentro do último)
				 */
				String diretorioAtual = System.getProperty("user.dir");
				String diretorioSrc = diretorioAtual + File.separator + "src";
				String diretorioResourceFiles = diretorioSrc + File.separator + "resourceFiles";
				/*
				 * Se o programa não estiver sendo executado na pasta referente ao projeto (no
				 * meu computador) e não existir uma pasta "src/resourceFiles" no local atual,
				 * abre uma janela de opções
				 */
				if (!diretorioAtual.equals(Paths.get("C://POO-trabalho//PortalAcademico").toAbsolutePath().toString())
						&& !(Log.verificarDiretorio(diretorioResourceFiles))) {
					janelaDeOpcoes();
				}
			}
		});
	}

	// Método auxiliar para exibir uma mensagem de erro
	public static void showErrorMessage(JLabel errorLabel) {
		// Usa uma caixa de mensagem de diálogo para exibir o JLabel de erro
		errorLabel.setHorizontalAlignment(JLabel.CENTER);
		errorLabel.setVerticalTextPosition(JLabel.BOTTOM);
		errorLabel.setHorizontalTextPosition(JLabel.CENTER);
		JOptionPane.showMessageDialog(null, errorLabel, "ERRO!", JOptionPane.PLAIN_MESSAGE);
	}

	// Método auxiliar para exibir uma mensagem de sucesso
	public static void showSuccessMessage(JLabel successLabel) {
		// Usa uma caixa de mensagem de diálogo para exibir o JLabel de sucesso
		successLabel.setHorizontalAlignment(JLabel.CENTER);
		successLabel.setVerticalTextPosition(JLabel.BOTTOM);
		successLabel.setHorizontalTextPosition(JLabel.CENTER);
		JOptionPane.showMessageDialog(null, successLabel, "SUCESSO!", JOptionPane.PLAIN_MESSAGE);
	}

	private static void janelaDeOpcoes() {
		// Cria um frame pra caixa de diálogo
		JFrame janelaDeOpcaoFrame = new JFrame();
		janelaDeOpcaoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janelaDeOpcaoFrame.setTitle("ARQUIVOS DE RECURSO NÃO ENCONTRADOS!");
		// Cria a caixa de diálogo
		JDialog janelaDeOpcaoDialog = new JDialog(janelaDeOpcaoFrame, "ARQUIVOS DE RECURSO NÃO ENCONTRADOS!", true);
		janelaDeOpcaoDialog.setSize(600, 200);
		janelaDeOpcaoDialog.setLocationRelativeTo(janelaDeOpcaoFrame);
		JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
		JLabel texto = new JLabel(
				"Os arquivos de recursos do software não foram localizados neste diretório. Como deseja proceder?",
				SwingConstants.CENTER);
		panel.add(texto);
		// Cria botões
		JButton botaoCriaArquivos = new JButton("Criar diretório e arquivos de recurso");
		botaoCriaArquivos.setPreferredSize(new Dimension(100, 50));
		JButton botaoBuscarNoComputador = new JButton("Buscar arquivos de recurso em outro diretório");
		botaoBuscarNoComputador.setPreferredSize(new Dimension(100, 50));
		// Adiciona botões ao panel
		panel.add(botaoCriaArquivos);
		panel.add(botaoBuscarNoComputador);
		botaoCriaArquivos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				criarArquivos();
				janelaDeOpcaoDialog.dispose();
			}
		});

		botaoBuscarNoComputador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selecionarArquivos();
				janelaDeOpcaoDialog.dispose();
			}
		});
		janelaDeOpcaoDialog.getContentPane().add(panel, BorderLayout.CENTER);
		janelaDeOpcaoDialog.setVisible(true);
	}

	// Método auxiliar para criar o diretório e arquivos
	private static void criarArquivos() {
		boolean erro = false;
		List<File> arquivos = new ArrayList<>();
		String d = null;
		try {
			// Cria o caminho do diretório src
			String diretorioSrc = System.getProperty("user.dir") + File.separator + "src";
			// Cria o caminho do diretório resourceFiles dentro de src
			String diretorioResourceFiles = diretorioSrc + File.separator + "resourceFiles";
			File diretorioNovo = new File(diretorioResourceFiles);
			// Cria o diretório novo onde o programa está em execução
			diretorioNovo.mkdirs();
			// Guarda o caminho desse diretório
			d = diretorioNovo.getAbsolutePath().toString();
			// Cria cinco arquivos .txt dentro de resourceFiles
			for (int i = 0; i < 5; i++) {
				if (i == 0) {
					File arquivo = new File(diretorioNovo, "logCadastros.txt");
					BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo, StandardCharsets.UTF_8, true));
					bw.write("16694492707,Administrador,09/10/2023,0,2023,Administrador");
					bw.close();
					arquivos.add(arquivo);
				} else if (i == 1) {
					File arquivo = new File(diretorioNovo, "logDisciplinasDocente.txt");
					BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo, StandardCharsets.UTF_8, true));
					bw.write("");
					bw.close();
					arquivos.add(arquivo);
				} else if (i == 2) {
					File arquivo = new File(diretorioNovo, "logDisciplinasEstudante.txt");
					BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo, StandardCharsets.UTF_8, true));
					bw.write("");
					bw.close();
					arquivos.add(arquivo);
				} else if (i == 3) {
					File arquivo = new File(diretorioNovo, "logLogins.txt");
					BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo, StandardCharsets.UTF_8, true));
					bw.write("admin;admin");
					bw.close();
					arquivos.add(arquivo);
				} else if (i == 4) {
					File arquivo = new File(diretorioNovo, "logNotasPorEstudante.txt");
					BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo, StandardCharsets.UTF_8, true));
					bw.write("");
					bw.close();
					arquivos.add(arquivo);
				}
			}
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}
		if (!erro) {
			/*
			 * Se nenhum erro ocorreu durante o processo anterior, os caminhos dos arquivos
			 * gerados e seu diretório são definidos como "padrão" dentro da classe Log
			 */
			Log.setNovosCaminhos(arquivos, d);
		} else {
			showErrorMessage(new JLabel("ERRO NA CRIAÇÃO DE ARQUIVOS | A APLICAÇÃO SERÁ ENCERRADA!"));
			System.exit(0);
		}
	}

	private static void selecionarArquivos() {
		List<File> arquivosSelecionados = new ArrayList<>();
		String caminho = null;
		// Cria a janela para seleção de arquivos da interface Swing
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Buscar arquivos de recurso em outro diretório (.txt)");
		fileChooser.setMultiSelectionEnabled(true);
		// Filtro para exibir e selecionar apenas arquivos .txt
		FileNameExtensionFilter filtro = new FileNameExtensionFilter("Arquivos de Texto (.txt)", "txt");
		fileChooser.setFileFilter(filtro);
		int resultado = fileChooser.showOpenDialog(null);
		try {
			if (resultado == JFileChooser.APPROVE_OPTION) {
				File[] arquivos = fileChooser.getSelectedFiles();
				if (arquivos.length < 5) {
					throw new GuiException("Não foram selecionados arquivos o suficiente para a execução do programa!");
				}
				int i = 0;
				for (File f : arquivos) {
					if (i == 0) {
						// Na primeira iteração, grava-se o caminho
						caminho = f.getParent().toString();
					} else {
						/*
						 * A partir da segunda iteração, o caminho atribuído na primeira iteração é
						 * comparado com o caminho do arquivo atual do laço. Não devem ser diferentes,
						 * caso sejam, lança-se exceção
						 */
						if (!(caminho.equals(f.getParent().toString()))) {
							throw new GuiException(
									"Um ou mais arquivos selecionados apresentam caminhos de diretorio divergentes!");
						}
					}
					arquivosSelecionados.add(f);
					i++;
				}
			}
			Log.setNovosCaminhos(arquivosSelecionados, caminho);
		} catch (GuiException e) {
			e.printStackTrace();
			showErrorMessage(new JLabel("ERRO NA SELEÇÃO DE ARQUIVOS | A APLICAÇÃO SERÁ ENCERRADA!"));
			System.exit(0);
		}
	}
}