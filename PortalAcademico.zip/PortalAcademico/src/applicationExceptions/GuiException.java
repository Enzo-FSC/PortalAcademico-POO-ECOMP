package applicationExceptions;

public class GuiException extends Exception {
	/*
	 * Classe GuiException estende a classe Exception (necessita ser tratada,
	 * diferente da RuntimeException)
	 */
	private static final long serialVersionUID = 1L;

	public GuiException(String msg) {
		/*
		 * Construtor envia para a super-classe a mensagem entre aspas + a mensagem
		 * passada por parâmetro
		 */
		super("GUI Exception Throwed: " + msg);
	}
}