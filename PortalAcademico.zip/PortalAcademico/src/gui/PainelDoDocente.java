package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import applicationExceptions.GuiException;
import resources.Disciplina;
import resources.LogCadastros;
import resources.LogDisciplinas;
import users.Estudante;

class ListarDisciplinasDocente {
	/*
	 * A classe "ListarDisciplinasDocente" tem apenas um construtor que cria uma
	 * janela de diálogo para mostrar informações sobre as disciplinas lecionadas
	 * por um docente. Quando uma instância dessa classe é criada, ela recebe o nome
	 * de usuário do docente como parâmetro, lista as disciplinas lecionadas por
	 * esse docente, atualiza o número de matriculados em cada disciplina, e
	 * apresenta esses dados em uma tabela JTable em uma caixa de diálogo (JDialog)
	 * com o nome do docente como título. Isso permite que o usuário visualize
	 * facilmente as disciplinas, seus códigos e a quantidade de matriculados em
	 * cada uma delas.
	 */
	public ListarDisciplinasDocente(String usuario) {

		StringBuilder dialogText = new StringBuilder();
		dialogText.append("Nome\t\t\tCódigo\t\t\tQuantidade de Matriculados\n");
		List<Disciplina> listaAux = LogDisciplinas.listarDisciplinasDocente(usuario);
		if (listaAux.isEmpty() || listaAux == null) {
			ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO LECIONA NENHUMA DISCIPLINA!"));
		} else {
			String[] columnNames = { "Nome", "Código", "Quantidade de Matriculados" };
			String[][] data = new String[listaAux.size()][3];
			for (Disciplina d : listaAux) {
				LogDisciplinas.atualizaMatriculados(d);
			}
			int i = 0;
			for (Disciplina d : listaAux) {
				String nome = d.getNomeDaDisciplina();
				String codigo = d.getId();
				String qntMatriculados = String.valueOf(LogDisciplinas.quantidadeDeMatriculados(d));
				data[i][0] = nome;
				data[i][1] = codigo;
				data[i][2] = qntMatriculados;
				i++;
			}
			JTable table = new JTable(data, columnNames);
			JScrollPane scrollPane = new JScrollPane(table);
			JDialog dialog = new JDialog();
			dialog.setTitle("Lista de Disciplinas Lecionadas - " + LogCadastros.encontrarDocente(usuario).getNome());
			dialog.setSize(750, 450);
			dialog.setLocationRelativeTo(null);
			dialog.add(scrollPane);
			dialog.setVisible(true);
		}
	}
}

class BuscarDisciplinaDocente extends JDialog {
	/*
	 * A classe "BuscarDisciplinaDocente" estende JDialog e cria uma janela de
	 * diálogo para permitir que um docente busque uma disciplina por seu código.
	 * Quando um objeto dessa classe é criado, ele recebe o JFrame pai, um título e
	 * o nome de usuário do docente. A janela de diálogo contém um campo de texto
	 * para inserir o código da disciplina e botões "Confirmar" e "Cancelar". Quando
	 * o botão "Confirmar" é acionado, a classe realiza uma busca pela disciplina
	 * com o código inserido e pode exibir mensagens de erro, abrir outra janela
	 * para mostrar informações sobre a disciplina ou permitir a publicação de
	 * notas. A classe também possui um botão "Cancelar" para fechar a janela de
	 * diálogo. Ela inclui um método buscar() que procura a disciplina na lista de
	 * disciplinas lecionadas pelo docente com base no código inserido e retorna a
	 * disciplina encontrada ou exibe mensagens de erro, caso algum ocorra.
	 */
	private static final long serialVersionUID = 1L;
	private JButton buscarBotão = new JButton("Buscar");
	private JButton cancelarBotão = new JButton("Cancelar");
	private JTextField cadeiraField = new JTextField(10);
	private String usuario = null;

	public BuscarDisciplinaDocente(JFrame parent, String title, String usuario) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);
		this.usuario = usuario;

		JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
		cadeiraField = new JTextField(10);
		buscarBotão = new JButton("Confirmar");
		cancelarBotão = new JButton("Cancelar");

		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(cadeiraField);
		panel.add(buscarBotão);
		panel.add(cancelarBotão);

		buscarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Disciplina d = buscar(cadeiraField.getText());
				if (title.equals("Buscar por Disciplina")) {
					if (d == null) {
						JLabel errorLabel = new JLabel("ERRO AO BUSCAR DISCIPLINA!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
					} else {
						List<Estudante> listaAux = LogDisciplinas.estudantesMatriculados(d);
						if (listaAux.isEmpty() || listaAux == null) {
							ProgramaPrincipal.showErrorMessage(new JLabel("NENHUM ESTUDANTE MATRICULADO!"));
						} else {
							dispose();
							new TabelaBuscaCadeiraDocente(parent, "Exibindo " + d.getNomeDaDisciplina(), d, usuario);
						}
					}
				} else if (title.equals("Publicar Notas")) {
					if (d == null) {
						JLabel errorLabel = new JLabel("ERRO AO BUSCAR DISCIPLINA!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
					} else {
						List<Estudante> listaAux = LogDisciplinas.estudantesMatriculados(d);
						if (listaAux.isEmpty() || listaAux == null) {
							ProgramaPrincipal.showErrorMessage(new JLabel("NENHUM ESTUDANTE MATRICULADO!"));
						} else {
							dispose();
							new PublicarNotas(d);
						}
					}
				}
			}
		});

		cancelarBotão.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}

	public Disciplina buscar(String codigoDisciplina) {
		List<Disciplina> listaDisciplinas = LogDisciplinas.listarDisciplinasDocente(usuario);
		try {
			if (listaDisciplinas.isEmpty() || listaDisciplinas == null) {
				throw new GuiException("Erro ao listar disciplinas vinculadas ao docente!");
			} else {
				for (Disciplina d : listaDisciplinas) {
					if (d == null) {
						throw new GuiException("Erro inesperado ao buscar disciplina!");
					}
					if (d.getId().equals(codigoDisciplina)) {
						return d;
					}
				}
				throw new GuiException("Disciplina não existe ou docente não a ministra!");
			}
		} catch (GuiException e) {
			e.printStackTrace();
		}
		return null;
	}
}

class PublicarNotas {
	/*
	 * A classe "PublicarNotas" cria uma janela de diálogo que permite a publicação
	 * de notas de estudantes em uma disciplina específica. O construtor recebe uma
	 * Disciplina, lista os estudantes matriculados, cria uma tabela com nomes dos
	 * alunos e campos em branco para as notas, e fornece botões "Confirmar" e
	 * "Cancelar". O usuário pode inserir as notas, confirmar as alterações e as
	 * notas são atualizadas no sistema. A caixa de diálogo exibe o nome da
	 * disciplina como título.
	 */
	private DefaultTableModel model;
	private JTable table;
	boolean erro = false;

	public PublicarNotas(Disciplina d) {
		List<Estudante> listaAux = LogDisciplinas.estudantesMatriculados(d);
		String[] nomesDosAlunos = new String[listaAux.size()];
		int k = 0;
		for (Estudante a : listaAux) {
			nomesDosAlunos[k] = a.getNome();
			k++;
		}
		StringBuilder dialogText = new StringBuilder();
		dialogText.append("Nome do Estudante\t\t\tNota 1\t\t\tNota 2\n");
		int qntMatriculados = LogDisciplinas.quantidadeDeMatriculados(d);
		String[] columnNames = { "Nome do Estudante", "Nota 1", "Nota 2" };
		model = new DefaultTableModel(columnNames, 0) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 1 || column == 2;
			}
		};
		for (int i = 0; i < qntMatriculados; i++) {
			model.addRow(new Object[] { nomesDosAlunos[i], "", "" });
		}
		table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		JButton confirmButton = new JButton("Confirmar");
		JButton cancelButton = new JButton("Cancelar");
		final JDialog dialog = new JDialog();
		dialog.setTitle("Publicar Notas de " + d.getNomeDaDisciplina());
		dialog.setSize(750, 450);
		dialog.setLocationRelativeTo(null);
		dialog.setLayout(new BorderLayout());
		dialog.add(scrollPane, BorderLayout.CENTER);
		confirmButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					for (int i = 0; i < qntMatriculados; i++) {
						String nota1 = (String) model.getValueAt(i, 1);
						String nota2 = (String) model.getValueAt(i, 2);
						if (!(LogDisciplinas.atualizaArquivoNotasPorEstudante(Double.parseDouble(nota1),
								Double.parseDouble(nota2), LogCadastros.encontrarEstudante(nomesDosAlunos[i]), d))) {
							throw new GuiException("Erro ao publicar notas de " + nomesDosAlunos[i]);
						}
					}
					dialog.dispose();
				} catch (NumberFormatException e1) {
					erro = true;
					e1.printStackTrace();
				} catch (GuiException e1) {
					erro = true;
					e1.printStackTrace();
				}
				if (erro) {
					ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO PUBLICAR NOTAS!"));
				} else {
					ProgramaPrincipal.showSuccessMessage(new JLabel("SUCESSO AO PUBLICAR NOTAS!"));
				}
			}
		});
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(confirmButton);
		buttonPanel.add(cancelButton);
		dialog.add(buttonPanel, BorderLayout.SOUTH);
		dialog.setVisible(true);
	}
}

class TabelaBuscaCadeiraDocente extends JDialog {
	/*
	 * A classe "TabelaBuscaCadeiraDocente" estende JDialog e cria uma janela de
	 * diálogo que exibe informações de uma disciplina encontrada durante uma busca
	 * por um docente. O construtor recebe um JFrame pai, um título, uma instância
	 * da classe Disciplina e o nome de usuário do docente como parâmetros. A janela
	 * é configurada com um tamanho específico e centralizada no JFrame pai. Ela
	 * exibe o nome da disciplina, seu código e a nota média da turma em uma tabela
	 * JTable.
	 */
	private static final long serialVersionUID = 1L;

	public TabelaBuscaCadeiraDocente(JFrame parent, String title, Disciplina d, String usuario) {
		super(parent, title, true);
		// Definindo o tamanho e a localização do JDialog.
		setSize(900, 77);
		setLocationRelativeTo(parent);
		// Criando um StringBuilder para construir o texto do JDialog.
		StringBuilder dialogText = new StringBuilder();
		// Adicionando cabeçalho ao texto do JDialog.
		dialogText.append("Nome\t\t\tCódigo\t\t\tNota Média da Turma\n");
		// Definindo os nomes das colunas da tabela.
		String[] columnNames = { "Nome", "Código", "Nota Média da Turma" };
		// Criando uma matriz de dados para preencher a tabela.
		String[][] data = new String[1][3];
		data[0][0] = d.getNomeDaDisciplina();
		// Obtém o nome da disciplina.
		data[0][1] = d.getId();
		// Obtém o código da disciplina.
		data[0][2] = String.valueOf(LogDisciplinas.mediaNotasPorDisciplina(d));
		// Calcula e obtém a nota média da turma.
		// Criando uma instância de JTable com os dados e os nomes das colunas.
		JTable table = new JTable(data, columnNames);
		/*
		 * Criando um JScrollPane para a tabela, permitindo rolar a tabela se
		 * necessário.
		 */
		JScrollPane scrollPane = new JScrollPane(table);
		// Criando uma instância de JDialog para exibir a tabela.
		JDialog dialog = new JDialog();
		// Configurando o título, tamanho e localização do JDialog.
		dialog.setTitle("Busca por Disciplina");
		dialog.setSize(900, 77);
		dialog.setLocationRelativeTo(null);
		// Adicionando o JScrollPane ao JDialog para exibir a tabela.
		dialog.add(scrollPane);
		// Tornando visível.
		dialog.setVisible(true);
	}
}

public class PainelDoDocente extends JFrame implements ActionListener {
	/*
	 * A classe "PainelDoDocente" estende JFrame e implementa a interface
	 * ActionListener. Ela inclui botões para executar ações, como listar
	 * disciplinas, buscar por disciplinas, publicar notas e alterar a senha do
	 * docente. A classe configura a janela do painel, adiciona uma imagem de fundo,
	 * organiza os botões em painéis e define ações para cada botão. Quando um botão
	 * é clicado, uma ação correspondente é executada, como exibir uma lista de
	 * disciplinas ou permitir a alteração da senha. O método "menu" inicia a
	 * aplicação, criando uma instância da classe e tornando a janela visível.
	 */
	protected static final long serialVersionUID = 1L;
	// Criando botões
	protected JButton buscarDisciplinaBotão = new JButton("Buscar por Disciplina");
	protected JButton listarDisciplinasBotão = new JButton("Listar Disciplinas");
	protected JButton publicarNotasBotão = new JButton("Publicar Notas");
	protected JButton alterarSenhaBotão = new JButton("Alterar Senha");
	protected JButton invisivelBotão = new JButton();
	protected JButton sairBotão = new JButton("Sair");
	protected static String usuario = null;
	protected String nomeDoArquivo = "images/fundoDocente.png";
	protected Path caminhoAbsoluto = Paths.get(nomeDoArquivo);

	public PainelDoDocente(String usuario) {
		PainelDoDocente.usuario = usuario;
		// Configurando o JFrame para tela cheia (baseia-se na resolução do monitor)
		setTitle("Painel do Docente | Portal Acadêmico"); // Título da Janela
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/*
		 * Adicionar um painel com a imagem de fundo usando uma InputStream para obter o
		 * caminho
		 */
		PlanoDeFundo panel = new PlanoDeFundo(getClass().getClassLoader().getResourceAsStream(nomeDoArquivo));
		/*
		 * Configurando um FlowLayout para "encaixotar" os botões numa posição
		 * específica
		 */
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 419));
		/*
		 * Definindo um tamanho fixo para os botões (200px de largura por 50px de
		 * altura)
		 */
		Dimension buttonSize = new Dimension(200, 50);
		buscarDisciplinaBotão.setPreferredSize(buttonSize);
		listarDisciplinasBotão.setPreferredSize(buttonSize);
		publicarNotasBotão.setPreferredSize(buttonSize);
		alterarSenhaBotão.setPreferredSize(buttonSize);
		invisivelBotão.setPreferredSize(buttonSize);
		sairBotão.setPreferredSize(buttonSize);
		// Adicionando os botões ao painel
		panel.add(buscarDisciplinaBotão);
		panel.add(listarDisciplinasBotão);
		panel.add(publicarNotasBotão);
		panel.add(alterarSenhaBotão);
		panel.add(invisivelBotão);
		panel.add(sairBotão);
		// Adicionando o painel ao JFrame
		add(panel);
		/*
		 * Criando um JPanel que organiza os botões em 2 linhas e 2 colunas, com
		 * espaçamento horizontal e vertical de 30px entre si
		 */
		JPanel panel1 = new JPanel(new GridLayout(2, 3, 20, 20));
		// Define cor de fundo para o JPanel (mesmo tom de cinza do background)
		panel1.setBackground(new Color(192, 192, 192));
		// Adicionando os botões ao JPanel
		panel1.add(buscarDisciplinaBotão);
		panel1.add(listarDisciplinasBotão);
		panel1.add(publicarNotasBotão);
		panel1.add(alterarSenhaBotão);
		panel1.add(invisivelBotão);
		panel1.add(sairBotão);
		// Adicionando o JPanel ao painel principal
		panel.add(panel1);
		// Adicionar os Listeners aos botões
		buscarDisciplinaBotão.addActionListener(this);
		listarDisciplinasBotão.addActionListener(this);
		publicarNotasBotão.addActionListener(this);
		alterarSenhaBotão.addActionListener(this);
		invisivelBotão.setVisible(false);
		sairBotão.addActionListener(this);
		new JanelaBoasVindas(usuario);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String buttonText = ((JButton) e.getSource()).getText(); // Cria String que recebe o nome do botão pressionado
		if (buttonText.equals("Sair")) {
			setVisible(false);
			ProgramaPrincipal.menu.setVisible(true);
		} else if (buttonText.equals("Listar Disciplinas")) {
			@SuppressWarnings("unused")
			ListarDisciplinasDocente dialog = new ListarDisciplinasDocente(usuario);
		} else if (buttonText.equals("Buscar por Disciplina")) {
			if (LogDisciplinas.listarDisciplinasDocente(usuario) == null
					|| LogDisciplinas.listarDisciplinasDocente(usuario).isEmpty()) {
				ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO LECIONA NENHUMA DISCIPLINA!"));
			} else {
				BuscarDisciplinaDocente dialog = new BuscarDisciplinaDocente(this, "Buscar por Disciplina", usuario);
				dialog.setVisible(true);
			}
		} else if (buttonText.equals("Publicar Notas")) {
			if (LogDisciplinas.listarDisciplinasDocente(usuario) == null
					|| LogDisciplinas.listarDisciplinasDocente(usuario).isEmpty()) {
				ProgramaPrincipal.showErrorMessage(new JLabel("VOCÊ NÃO LECIONA NENHUMA DISCIPLINA!"));
			} else {
				BuscarDisciplinaDocente dialog = new BuscarDisciplinaDocente(this, "Publicar Notas", usuario);
				dialog.setVisible(true);
			}
		} else if (buttonText.equals("Alterar Senha")) {
			AlterarSenha dialog = new AlterarSenha(this, buttonText, usuario);
			dialog.setVisible(true);
		}
	}
}