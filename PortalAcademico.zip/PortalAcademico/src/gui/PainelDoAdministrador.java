package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import applicationExceptions.GuiException;
import resources.Disciplina;
import resources.Log;
import resources.LogCadastros;
import resources.LogDisciplinas;
import users.Docente;
import users.Estudante;
import users.Pessoa;

class RemoverEstudanteFormDialog extends JDialog {
	/*
	 * A classe RemoverEstudanteFormDialog implementa uma janela de diálogo que
	 * permite a remoção de estudantes do sistema. Ela estende a classe JDialog e
	 * inclui campos para a entrada da matrícula do estudante, botões de “Confirmar”
	 * e “Cancelar”. No construtor, a janela de diálogo é inicializada e, então, um
	 * painel é criado com campos de entrada e botões, e eventos são configurados
	 * para os botões. Quando o botão "Confirmar" é pressionado, ele chama o método
	 * removerCadastroEstudante() e fecha a janela de diálogo. O botão "Cancelar"
	 * simplesmente fecha a janela de diálogo.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField matriculaField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public RemoverEstudanteFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5)); // GridLayout de 2 linhas e 2 colunas

		// Adiciona botões e campo de matrícula ao JPanel
		panel.add(new JLabel("Matrícula do Estudante:"));
		panel.add(matriculaField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!LogCadastros.verificarClasseCadastro(matriculaField.getText()).equals("Estudante")) {
					// Emite mensagem de erro se usuário não for estudante
					ProgramaPrincipal.showErrorMessage(new JLabel("O USUÁRIO INFORMADO NÃO É ESTUDANTE!"));
				} else {
					LogCadastros.remover(matriculaField.getText()); // Chamada método remover
					dispose();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

class RemoverDocenteFormDialog extends JDialog {
	/*
	 * A classe RemoverDocenteFormDialog faz exatamente a mesma coisa que a classe
	 * RemoverEstudanteFormDialog, porém, com dados referentes a docentes.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField siapeField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public RemoverDocenteFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));

		panel.add(new JLabel("SIAPE:"));
		panel.add(siapeField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!LogCadastros.verificarClasseCadastro(siapeField.getText()).equals("Docente")) {
					// Emite mensagem de erro se usuário não for docente
					ProgramaPrincipal.showErrorMessage(new JLabel("O USUÁRIO INFORMADO NÃO É DOCENTE!"));
				} else {
					LogCadastros.remover(siapeField.getText()); // Chamada método remover
					dispose();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

class CadastrarDocenteFormDialog extends JDialog {
	/*
	 * A classe CadastrarDocenteFormDialog implementa uma janela de diálogo que
	 * permite o cadastro de informações de um docente. Ela estende a classe JDialog
	 * e inclui campos de entrada de texto para o nome, SIAPE, CPF, data de
	 * nascimento e ano de ingresso do docente. Além disso, a classe possui os
	 * botões "Confirmar" e "Cancelar". Dois ActionListeners são configurados para
	 * os botões. O botão "Confirmar" executa o método realizarCadastroDocente(),
	 * que tenta criar um objeto Docente com base nas informações inseridas nos
	 * campos de texto.
	 */
	protected static final long serialVersionUID = 1L;
	// Criando botões e campos de preenchimento
	protected JTextField nomeField = new JTextField(10);
	protected JTextField siapeField = new JTextField(10);
	protected JTextField cpfField = new JPasswordField(10);
	protected JTextField dataDeNascimentoField = new JTextField(10);
	protected JTextField anoDeIngresso = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");
	protected SimpleDateFormat ano = new SimpleDateFormat("yyyy");
	// Objeto "formatador" de data para guardar a informação "anoDeIngresso"
	protected SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	// Objeto "formatador" de data para guardar a informação "dataDeNascimento"

	public CadastrarDocenteFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(500, 300);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10)); // O grid tem 6 linhas e 2 colunas

		panel.add(new JLabel("Nome do Docente:"));
		panel.add(nomeField);
		panel.add(new JLabel("SIAPE:"));
		panel.add(siapeField);
		panel.add(new JLabel("CPF do Docente:"));
		panel.add(cpfField);
		panel.add(new JLabel("Data de Nascimento do Docente:"));
		panel.add(dataDeNascimentoField);
		panel.add(new JLabel("Ano de Ingresso na Instituição:"));
		panel.add(anoDeIngresso);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Chama o método realizarCadastroDocente
				realizarCadastroDocente();
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Fecha a janela de diálogo
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}

	protected void realizarCadastroDocente() {
		String cpf = cpfField.getText();
		boolean erroCadastroDocente = false;
		try {
			if (cpfField.getText().equals("") || cpfField.getText() == null) {
				cpf = LogCadastros.gerarCPF();
			}
			// Verifica se nenhum campo de preenchimento obrigatório ficou vazio
			if (nomeField.getText().equals("") || siapeField.getText().equals("")
					|| dataDeNascimentoField.getText().equals("") || anoDeIngresso.getText().equals("")) {
				throw new GuiException("Campo de preenchimento obrigatório vazio!\n");
				// Caso algum campo esteja vazio, é lançada uma exceção GuiException
			}
			if (!(Pessoa.validadorCPF(cpf))) {
				// Se o CPF é inválido, lança exceção GuiException
				throw new GuiException("O CPF informado no cadastro é inválido!");
			} else {
				// Instancia docente e o adiciona nos cadastros
				LogCadastros.adicionar(new Docente(cpf, nomeField.getText(), sdf.parse(dataDeNascimentoField.getText()),
						Integer.parseInt(siapeField.getText()), Integer.parseInt(anoDeIngresso.getText())));
				dispose();
			}
		} catch (ParseException e) {
			erroCadastroDocente = true;
			e.printStackTrace();
		} catch (GuiException e) {
			erroCadastroDocente = true;
			e.printStackTrace();
		}
		if (erroCadastroDocente) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO CADASTRAR DOCENTE!"));
		}
	}
}

class CadastrarEstudanteFormDialog extends JDialog {
	/*
	 * A classe CadastrarEstudanteFormDialog faz exatamente a mesma coisa que a
	 * classe CadastrarDocenteFormDialog, porém, com dados referentes a estudantes.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField nomeField = new JTextField(10);
	protected JTextField matriculaField = new JTextField(10);
	protected JTextField cpfField = new JPasswordField(10);
	protected JTextField dataDeNascimentoField = new JTextField(10);
	protected JTextField anoDeIngresso = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");
	protected SimpleDateFormat ano = new SimpleDateFormat("yyyy");
	protected SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	public CadastrarEstudanteFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(500, 300);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

		panel.add(new JLabel("Nome do Ingresso:"));
		panel.add(nomeField);
		panel.add(new JLabel("Matrícula do Ingresso:"));
		panel.add(matriculaField);
		panel.add(new JLabel("CPF do Ingresso:"));
		panel.add(cpfField);
		panel.add(new JLabel("Data de Nascimento do Ingresso:"));
		panel.add(dataDeNascimentoField);
		panel.add(new JLabel("Ano de Ingresso:"));
		panel.add(anoDeIngresso);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				realizarCadastroEstudante();
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}

	protected void realizarCadastroEstudante() {
		String cpf = cpfField.getText();
		boolean erroCadastroEstudante = false;
		try {
			if (cpfField.getText().equals("")) {
				cpf = LogCadastros.gerarCPF();
			}
			if (nomeField.getText().equals("") || matriculaField.getText().equals("")
					|| dataDeNascimentoField.getText().equals("") || anoDeIngresso.getText().equals("")) {
				throw new GuiException("Campo de preenchimento obrigatório vazio!\n");
			}
			if (!(Pessoa.validadorCPF(cpf))) {
				// Se o CPF é inválido, lança exceção GuiException
				throw new GuiException("O CPF informado no cadastro é inválido!");
			} else {
				// Instancia estudante e o adiciona nos cadastros
				LogCadastros
						.adicionar(new Estudante(cpf, nomeField.getText(), sdf.parse(dataDeNascimentoField.getText()),
								Integer.parseInt(matriculaField.getText()), Integer.parseInt(anoDeIngresso.getText())));
				dispose();
			}
		} catch (ParseException e) {
			erroCadastroEstudante = true;
			e.printStackTrace();
		} catch (GuiException e) {
			erroCadastroEstudante = true;
			e.printStackTrace();
		}
		if (erroCadastroEstudante) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO CADASTRAR ESTUDANTE!"));
		}
	}
}

class AlterarMatriculaFormDialog extends JDialog {
	/*
	 * A classe Java AlterarMatriculaFormDialog é uma classe que estende JDialog e
	 * cria uma janela de diálogo para alterar matrículas de estudantes. Ela possui
	 * quatro campos, sendo dois de texto (um para a matrícula atual e outro para a
	 * nova matrícula) e dois botões, “Confirmar” e “Cancelar”. Quando o botão
	 * "Confirmar" é clicado, a classe chama o método estático
	 * alterarIdentificador() da classe LogCadastros, passando por parâmetro os
	 * campos matriculaAtualField e matriculaNovaField e, em seguida, fecha a janela
	 * de diálogo. O outro botão apenas fecha a janela de diálogo e cancela a
	 * operação.
	 */
	protected static final long serialVersionUID = 1L;
	// Criando botões e campos para preenchimento
	protected JTextField matriculaAtualField = new JTextField(10);
	protected JTextField matriculaNovaField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public AlterarMatriculaFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5)); // O GridLayout tem 3 linhas e 2 colunas

		panel.add(new JLabel("Matrícula Atual:"));
		panel.add(matriculaAtualField);
		panel.add(new JLabel("Nova Matrícula:"));
		panel.add(matriculaNovaField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!(LogCadastros.verificarClasseCadastro(matriculaAtualField.getText()).equals("Estudante"))) {
					// Testa se o usuário informado é estudante
					ProgramaPrincipal.showErrorMessage(new JLabel("O USUÁRIO INFORMADO NÃO É ESTUDANTE!"));
				} else if (!(LogCadastros.verificarClasseCadastro(matriculaNovaField.getText())
						.equals("Inconclusivo"))) {
					// Testa se já existe um usuário com essa matrícula
					ProgramaPrincipal.showErrorMessage(new JLabel("JÁ EXISTE UM ESTUDANTE COM ESSA MATRÍCULA!"));
				} else {
					// Chama o método alterarMatricula
					LogCadastros.alterarMatricula(matriculaAtualField.getText(), matriculaNovaField.getText());
					dispose();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Fecha a janela de diálogo
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

class TrancamentoFormDialog extends JDialog {
	/*
	 * A classe TrancamentoFormDialog estende "JDialog" e implementa uma janela de
	 * diálogo que permite ao administrador especificar a matrícula de um estudante
	 * e o código da disciplina que ele deseja trancar. Quando o botão "Confirmar" é
	 * clicado, a classe chama o método listarDisciplinasAluno(), da classe
	 * LogDisciplinas, para listar as disciplinas associadas ao estudante. Em
	 * seguida, ela procura, na lista de disciplinas, a disciplina com o código
	 * informado. Se a disciplina for encontrada, é armazenada em "t".
	 * Posteriormente, há a chamada do método realizarTrancamento() também de
	 * LogDisciplinas, passando a matrícula do estudante e a cadeira “t”. O botão
	 * "Cancelar" apenas fecha a janela de diálogo sem executar nenhuma ação
	 * adicional.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField matriculaField = new JTextField(10);
	protected JTextField cadeiraField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public TrancamentoFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(300, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));

		panel.add(new JLabel("Matrícula do Estudante:"));
		panel.add(matriculaField);
		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(cadeiraField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (!(LogCadastros.verificarClasseCadastro(matriculaField.getText()).equals("Estudante"))) {
						throw new GuiException("O usuário informado não é estudante ou não está cadastrado!");
					}
					/*
					 * Lista todas as disciplinas do estudante para verificar se ele está
					 * matriculado
					 */
					List<Disciplina> listaAux = LogDisciplinas.listarDisciplinasEstudante(matriculaField.getText());
					Disciplina t = null;
					for (Disciplina d : listaAux) {
						if (cadeiraField.getText().equals(d.getId())) {
							t = d;
							break;
						}
					}
					if (t != null) {
						LogDisciplinas.realizarTrancamento(LogCadastros.encontrarEstudante(matriculaField.getText()),
								t);
						dispose();
					} else {
						throw new GuiException("O estudante não está matriculado nessa disciplina!");
					}
				} catch (GuiException e1) {
					ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO REALIZAR TRANCAMENTO!"));
					e1.printStackTrace();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

class ListarCadastros {
	/*
	 * A classe ListarCadastros implementa uma janela de diálogo que exibe uma lista
	 * de cadastros a partir de um arquivo. Ela não possui atributos, apenas um
	 * construtor padrão. Quando um objeto dessa classe é instanciado, o conteúdo do
	 * arquivo de texto "logCadastros.txt" é lido, sendo que o caminho para esse
	 * arquivo é relativo, transformado em absoluto por meio do método get() da
	 * classe Paths (da própria linguagem). Durante a leitura do arquivo, a classe
	 * constrói uma tabela de dados a partir das informações lidas. Ela inicia a
	 * construção do texto exibido na janela de diálogo com uma linha de cabeçalho e
	 * cria um array de strings para armazenar os dados da tabela. O leitor “br”
	 * percorre o arquivo linha a linha, dividindo cada linha em elementos
	 * individuais. Em seguida, ela verifica se o segundo elemento da linha não é
	 * igual a "Administrador". Se essa condição for atendida, os dados da linha são
	 * incluídos na tabela. Depois de percorrer todas as linhas do arquivo, a classe
	 * cria uma JTable, usando os dados da tabela e os nomes das colunas. A JTable é
	 * inserida em um JScrollPane para lidar com a rolagem da tabela caso ela tenha
	 * muitas linhas. Essa tabela é exibida em uma JDialog, configurada como
	 * visível.
	 */
	public ListarCadastros() {
		boolean erroListar = false;
		try (BufferedReader br = new BufferedReader(new FileReader(Log.getPath("logCadastros.txt")))) {
			String linha = br.readLine();
			StringBuilder dialogText = new StringBuilder();
			dialogText.append("Nome\t\t\tAtribuição\t\t\tIdentificador\n");
			String[] columnNames = { "Nome", "Atribuição", "Identificador" };
			String[][] data = new String[LogCadastros.contador() - 1][3];
			/*
			 * A matriz de dados tem quantidade de linhas igual ao número de linhas do
			 * arquivo menos um, já que não é mostrado o usuário Administrador.
			 */
			// Monta a tabela
			int l = 0;
			while (linha != null) {
				String[] item = linha.split(",");
				if (!(item[1].equals("Administrador"))) {
					data[l][0] = item[1];
					data[l][1] = item[5];
					data[l][2] = item[3];
					l++;
				}
				linha = br.readLine();
			}
			JTable table = new JTable(data, columnNames);
			JScrollPane scrollPane = new JScrollPane(table);
			JDialog dialog = new JDialog();
			dialog.setTitle("Lista de Cadastros");
			dialog.setSize(600, 300);
			dialog.setLocationRelativeTo(null);
			dialog.add(scrollPane);
			dialog.setVisible(true);
		} catch (FileNotFoundException e) {
			erroListar = true;
			e.printStackTrace();
		} catch (IOException e) {
			erroListar = true;
			e.printStackTrace();
		}
		if (erroListar) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO LISTAR CADASTROS!"));
		}
	}
}

class SubstituirDocente extends JDialog {
	/*
	 * A classe SubstituirDocente é uma classe que estende "JDialog" e cria uma
	 * janela de diálogo para substituir o docente encarregado por uma disciplina. A
	 * classe possui três campos de texto (para o SIAPE do novo docente, o SIAPE do
	 * docente atual e o código da disciplina) e dois botões, o “Confirmar” e o
	 * “Cancelar”. Quando o primeiro botão é clicado, a classe chama o método
	 * substituirDocente() da classe LogDisciplinas com os valores dos campos
	 * "cadeiraField," "novoProfessorField," e "atualProfessorField." O método
	 * encontrarProfessor(), também da classe LogCadastros, é utilizado para
	 * encontrar os docentes associados aos SIAPE fornecidos. Após a substituição de
	 * docente, a janela de diálogo será fechada. O botão "Cancelar" apenas fecha a
	 * janela de diálogo.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField novoDocenteField = new JTextField(10);
	protected JTextField atualDocenteField = new JTextField(10);
	protected JTextField cadeiraField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public SubstituirDocente(JFrame parent, String title) {
		super(parent, title, true);
		setSize(350, 150);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));

		panel.add(new JLabel("SIAPE do Novo Docente:"));
		panel.add(novoDocenteField);
		panel.add(new JLabel("SIAPE do Atual Docente:"));
		panel.add(atualDocenteField);
		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(cadeiraField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					/*
					 * Testa se os usuários informados são, de fato, docentes, e se o atual ministra
					 * a disciplina que será movida, além de checar se o novo já não a ministra
					 */
					if (!(LogCadastros.verificarClasseCadastro(novoDocenteField.getText()).equals("Docente"))) {
						throw new GuiException("O usuário informado não é docente ou não está cadastrado!");
					}
					if (!(LogCadastros.verificarClasseCadastro(atualDocenteField.getText()).equals("Docente"))) {
						throw new GuiException("O usuário informado não é docente ou não está cadastrado!");
					}
					List<Disciplina> listaAux = LogDisciplinas.listarDisciplinasDocente(atualDocenteField.getText());
					Disciplina a = null;
					Disciplina n = null;
					for (Disciplina d : listaAux) {
						if (cadeiraField.getText().equals(d.getId())) {
							a = d;
							break;
						}
					}
					listaAux = LogDisciplinas.listarDisciplinasDocente(novoDocenteField.getText());
					for (Disciplina d : listaAux) {
						if (cadeiraField.getText().equals(d.getId())) {
							n = d;
							break;
						}
					}
					if (a == null) {
						throw new GuiException("O docente informado não ministra essa disciplina!");
					} else if (n != null) {
						throw new GuiException("O docente informado já ministra essa disciplina!");
					}
					LogDisciplinas.substituirDocente(cadeiraField.getText(),
							LogCadastros.encontrarDocente(novoDocenteField.getText()),
							LogCadastros.encontrarDocente(atualDocenteField.getText()));
					dispose();
				} catch (GuiException e1) {
					ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO SUBSTITUIR DOCENTE!"));
					e1.printStackTrace();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}
}

class CadastrarDisciplinaFormDialog extends JDialog {
	/*
	 * A classe CadastrarDisciplinaFormDialog tem ação semelhante às classes
	 * CadastrarDocenteFormDialog e CadastrarEstudanteFormDialog, porém, com dados
	 * referentes à uma nova disciplina a ser adicionada no sistema.
	 */
	protected static final long serialVersionUID = 1L;
	protected JTextField nomeDaDisciplinaField = new JTextField(10);
	protected JTextField codigoDaDisciplinaField = new JTextField(10);
	protected JTextField professorEncarregadoField = new JTextField(10);
	protected JButton enterButton = new JButton("Confirmar");
	protected JButton cancelButton = new JButton("Cancelar");

	public CadastrarDisciplinaFormDialog(JFrame parent, String title) {
		super(parent, title, true);
		setSize(450, 200);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));

		panel.add(new JLabel("Nome da Disciplina:"));
		panel.add(nomeDaDisciplinaField);
		panel.add(new JLabel("Código da Disciplina:"));
		panel.add(codigoDaDisciplinaField);
		panel.add(new JLabel("SIAPE do Docente Encarregado:"));
		panel.add(professorEncarregadoField);
		panel.add(enterButton);
		panel.add(cancelButton);

		enterButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean erro = false;
				try {
					/*
					 * Verifica se o usuário informado é docente, se ele já não ministra a
					 * disciplina a ser cadastrada
					 */
					if (!(LogCadastros.verificarClasseCadastro(professorEncarregadoField.getText())
							.equals("Docente"))) {
						throw new GuiException("O usuário informado não é docente ou não está cadastrado!");
					}
					List<Disciplina> listaAux = LogDisciplinas
							.listarDisciplinasDocente(professorEncarregadoField.getText());
					Disciplina a = null;
					for (Disciplina d : listaAux) {
						if (codigoDaDisciplinaField.getText().equals(d.getId())) {
							a = d;
							break;
						}
					}
					if (a != null) {
						throw new GuiException("O docente já ministra essa disciplina!");
					}
				} catch (GuiException e1) {
					erro = true;
					e1.printStackTrace();
				}
				if (erro) {
					ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO CADASTRAR DISCIPLINA!"));
				} else {
					LogDisciplinas.cadastrarDisciplina(nomeDaDisciplinaField.getText(),
							codigoDaDisciplinaField.getText(),
							LogCadastros.encontrarDocente(professorEncarregadoField.getText()));
					dispose();
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		getContentPane().add(panel, BorderLayout.CENTER);
	}

}

public class PainelDoAdministrador extends JFrame implements ActionListener {
	protected static final long serialVersionUID = 1L;
	// Criando botões
	protected JButton trancamentoBotão = new JButton("Realizar Trancamento");
	protected JButton removerEstudanteBotão = new JButton("Remover Estudante");
	protected JButton removerDocenteBotão = new JButton("Remover Docente");
	protected JButton cadastrarEstudanteBotão = new JButton("Cadastrar Estudante");
	protected JButton cadastrarDocenteBotão = new JButton("Cadastrar Docente");
	protected JButton alterarMatriculaBotão = new JButton("Alterar Matrícula");
	protected JButton listarCadastrosBotão = new JButton("Listar Cadastros");
	protected JButton substituirDocenteBotão = new JButton("Substituir Docente");
	protected JButton adicionarDisciplinaBotão = new JButton("Cadastrar Disciplina");
	protected JButton sairBotão = new JButton("Sair");
	protected static String usuario = null;
	protected String nomeDoArquivo = "images/fundoAdm.png";

	public PainelDoAdministrador(String usuario) {
		PainelDoAdministrador.usuario = usuario;
		// Configurando o JFrame para tela cheia (baseia-se na resolução do monitor)
		setTitle("Painel do Administrador | Portal Acadêmico"); // Título da Janela
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		/*
		 * Adicionar um painel com a imagem de fundo usando uma InputStream para obter o
		 * caminho
		 */
		PlanoDeFundo panel = new PlanoDeFundo(getClass().getClassLoader().getResourceAsStream(nomeDoArquivo));
		/*
		 * Configurando um FlowLayout para "encaixotar" os botões numa posição
		 * específica
		 */
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 419));

		/*
		 * Definindo um tamanho fixo para os botões (200px de largura por 50px de
		 * altura)
		 */
		Dimension buttonSize = new Dimension(200, 50);
		trancamentoBotão.setPreferredSize(buttonSize);
		removerEstudanteBotão.setPreferredSize(buttonSize);
		removerDocenteBotão.setPreferredSize(buttonSize);
		cadastrarEstudanteBotão.setPreferredSize(buttonSize);
		cadastrarDocenteBotão.setPreferredSize(buttonSize);
		alterarMatriculaBotão.setPreferredSize(buttonSize);
		listarCadastrosBotão.setPreferredSize(buttonSize);
		substituirDocenteBotão.setPreferredSize(buttonSize);
		adicionarDisciplinaBotão.setPreferredSize(buttonSize);
		sairBotão.setPreferredSize(buttonSize);

		// Adicionando os botões ao painel
		panel.add(trancamentoBotão);
		panel.add(removerEstudanteBotão);
		panel.add(removerDocenteBotão);
		panel.add(cadastrarEstudanteBotão);
		panel.add(cadastrarDocenteBotão);
		panel.add(alterarMatriculaBotão);
		panel.add(listarCadastrosBotão);
		panel.add(substituirDocenteBotão);
		panel.add(adicionarDisciplinaBotão);
		panel.add(sairBotão);

		// Adicionando o painel ao JFrame
		add(panel);

		/*
		 * Criando um JPanel que organiza os botões em 2 linhas e 4 colunas, com
		 * espaçamento horizontal e vertical de 10px entre si
		 */
		JPanel panel1 = new JPanel(new GridLayout(2, 5, 25, 25));
		// Define cor de fundo para o JPanel (mesmo tom de cinza do background)
		panel1.setBackground(new Color(192, 192, 192));

		// Adicionando os botões ao JPanel
		panel1.add(cadastrarEstudanteBotão);
		panel1.add(cadastrarDocenteBotão);
		panel1.add(alterarMatriculaBotão);
		panel1.add(adicionarDisciplinaBotão);
		panel1.add(listarCadastrosBotão);
		panel1.add(removerEstudanteBotão);
		panel1.add(removerDocenteBotão);
		panel1.add(substituirDocenteBotão);
		panel1.add(trancamentoBotão);
		panel1.add(sairBotão);

		// Adicionando o JPanel ao painel principal
		panel.add(panel1);

		// Adicionar os Listeners de ação aos botões
		trancamentoBotão.addActionListener(this);
		removerEstudanteBotão.addActionListener(this);
		removerDocenteBotão.addActionListener(this);
		cadastrarEstudanteBotão.addActionListener(this);
		cadastrarDocenteBotão.addActionListener(this);
		alterarMatriculaBotão.addActionListener(this);
		listarCadastrosBotão.addActionListener(this);
		substituirDocenteBotão.addActionListener(this);
		adicionarDisciplinaBotão.addActionListener(this);
		sairBotão.addActionListener(this);
		new JanelaBoasVindas(usuario);
	}

	/*
	 * Configurando o método actionPerformed conforme necessidade da interface do
	 * Painel do Administrador
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		String buttonText = ((JButton) e.getSource()).getText(); // Cria String que recebe o nome do botão pressionado
		/*
		 * Será feita uma comparação dos textos de cada botão com essa String. Assim,
		 * será tomada a decisão de qual ação desempenhar. O resultado de quase todas as
		 * ações é simplesmente abrir uma caixa de diálogo configurada especialmente
		 * para cada situação, sendo que, essas caixas de diálogo servem como
		 * formulários. As exceções são: o botão "Listar Cadastros", pois a ação
		 * atribuída a ele é criar uma tabela JTable para exibir os dados e uma caixa de
		 * diálogo para exibir a tabela, e o botão "Sair", que simplesmente fecha a
		 * janela e encerra o programa
		 */
		if (buttonText.equals("Realizar Trancamento")) {
			TrancamentoFormDialog dialog = new TrancamentoFormDialog(this, "Realizar Trancamento");
			dialog.setVisible(true);
		} else if (buttonText.equals("Remover Estudante")) {
			RemoverEstudanteFormDialog dialog = new RemoverEstudanteFormDialog(this, "Remover Estudante");
			dialog.setVisible(true);
		} else if (buttonText.equals("Sair")) {
			setVisible(false);
			ProgramaPrincipal.menu.setVisible(true);
		} else if (buttonText.equals("Listar Cadastros")) {
			@SuppressWarnings("unused")
			ListarCadastros dialog = new ListarCadastros();
		} else if (buttonText.equals("Cadastrar Estudante")) {
			CadastrarEstudanteFormDialog dialog = new CadastrarEstudanteFormDialog(this, "Cadastrar Estudante");
			dialog.setVisible(true);
		} else if (buttonText.equals("Cadastrar Docente")) {
			CadastrarDocenteFormDialog dialog = new CadastrarDocenteFormDialog(this, "Cadastrar Docente");
			dialog.setVisible(true);
		} else if (buttonText.equals("Remover Docente")) {
			RemoverDocenteFormDialog dialog = new RemoverDocenteFormDialog(this, "Remover Docente");
			dialog.setVisible(true);
		} else if (buttonText.equals("Alterar Matrícula")) {
			AlterarMatriculaFormDialog dialog = new AlterarMatriculaFormDialog(this, "Alterar Matrícula");
			dialog.setVisible(true);
		} else if (buttonText.equals("Substituir Docente")) {
			SubstituirDocente dialog = new SubstituirDocente(this, "Substituir Docente");
			dialog.setVisible(true);
		} else if (buttonText.equals("Cadastrar Disciplina")) {
			CadastrarDisciplinaFormDialog dialog = new CadastrarDisciplinaFormDialog(this, "Cadastrar Disciplina");
			dialog.setVisible(true);
		}
	}
}