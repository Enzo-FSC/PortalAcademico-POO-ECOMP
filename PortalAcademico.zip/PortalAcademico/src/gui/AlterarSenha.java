package gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import applicationExceptions.GuiException;
import resources.LogCadastros;
import resources.LogLogins;
import users.Docente;
import users.Estudante;

public class AlterarSenha extends JDialog {
	/*
	 * A classe AlterarSenha implementa a janela de diálogo (JDialog) que é aberta
	 * quando usuários com atribuição de Estudante ou Docente clicam no botão
	 * correspondente dentro do seu painel específico.
	 */
	private static final long serialVersionUID = 1L;
	// Botões e campos de senha
	private JButton alterarSenhaBotão = new JButton("Confirmar");
	private JButton cancelarBotão = new JButton("Cancelar");
	private JPasswordField senhaAtualField = new JPasswordField(10);
	private JPasswordField senhaNovaField = new JPasswordField(10);

	// Construtor da classe
	public AlterarSenha(JFrame parent, String title, String usuario) {
		// Chama o construtor da classe-mãe (JDialog)
		super(parent, title, true);
		// Configura o tamanho e a localização da janela
		setSize(300, 150);
		setLocationRelativeTo(parent);
		// Cria um painel com GridLayout para organizar os componentes
		JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
		panel.add(new JLabel("Digite a senha atual:"));
		panel.add(senhaAtualField);
		panel.add(new JLabel("Digite a senha nova:"));
		panel.add(senhaNovaField);
		panel.add(alterarSenhaBotão);
		panel.add(cancelarBotão);
		// Adiciona ActionListener para o botão "Confirmar"
		alterarSenhaBotão.addActionListener(new ActionListener() {
			/*
			 * Verifica-se a atribuição do usuário que fez login e está tentando alterar sua
			 * senha. Em ambos os casos, o procedimento é semelhante: instancia-se um objeto
			 * da classe correspondente à atribuição do usuário e, em seguida, é armazenado
			 * seu último nome. Caso o teste do método verificarClasseCadastro() tenha
			 * resultado inconclusivo, isto é, não for possível verificar a atribuição do
			 * usuário, é lançada uma exceção GuiException. Posterior ao teste de
			 * atribuição, é feita, então, a chamada do método alterarSenha(), passando como
			 * parâmetros o usuário (neste caso, seu identificador), a senha atual que foi
			 * digitada no campo especificado, a nova senha e, por fim, o último nome do
			 * usuário. Caso o retorno do método seja verdadeiro, a janela de diálogo é
			 * fechada, isto indica que o processo foi bem sucedido. Caso contrário, é
			 * criada uma segunda janela de diálogo informado falha na operação.
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					// Inicializa a variável para armazenar o último nome do usuário
					String ultimoNome = null;
					// Verifica a atribuição do usuário (Estudante ou Docente) e obtém o último nome
					if (LogCadastros.verificarClasseCadastro(usuario).equals("Estudante")) {
						Estudante a = LogCadastros.encontrarEstudante(usuario);
						String fields[] = a.getNome().split(" ");
						ultimoNome = fields[fields.length - 1];
					} else if (LogCadastros.verificarClasseCadastro(usuario).equals("Docente")) {
						Docente p = LogCadastros.encontrarDocente(usuario);
						String fields[] = p.getNome().split(" ");
						ultimoNome = fields[fields.length - 1];
					} else {
						/*
						 * Lança uma exceção GuiException se a atribuição do usuário não puder ser
						 * verificada
						 */
						JLabel errorLabel = new JLabel(
								"USUÁRIO NÃO ESTÁ CADASTRADO NO SISTEMA OU POSSUI DADOS INVÁLIDOS!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
						throw new GuiException("Não foi possível confirmar a atribuição do usuário no sistema!");
					}
					// Chama o método para alterar a senha e exibe uma mensagem em caso de falha
					if (!(LogLogins.alterarSenha(usuario, senhaAtualField.getPassword(), senhaNovaField.getPassword(),
							ultimoNome))) {
						JLabel errorLabel = new JLabel("ERRO AO ALTERAR A SENHA | SENHA ATUAL INVÁLIDA!");
						ProgramaPrincipal.showErrorMessage(errorLabel);
					} else {
						// Exibe mensagem de sucesso
						JLabel successLabel = new JLabel("SUCESSO AO ALTERAR A SENHA!");
						ProgramaPrincipal.showSuccessMessage(successLabel);
						// Fecha a janela de diálogo
						dispose();
					}
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (GuiException e1) {
					e1.printStackTrace();
				}
			}
		});
		// Adiciona ActionListener para o botão "Cancelar"
		cancelarBotão.addActionListener(new ActionListener() {
			/*
			 * Este botão apenas cancela a operação de troca de senha, fechando a janela de
			 * diálogo.
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				// Fecha a janela de diálogo sem realizar a operação de alteração de senha
				dispose();
			}
		});
		// Adiciona o painel à região central do conteúdo da janela
		getContentPane().add(panel, BorderLayout.CENTER);
	}
}