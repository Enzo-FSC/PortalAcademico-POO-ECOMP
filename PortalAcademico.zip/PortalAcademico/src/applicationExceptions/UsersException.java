package applicationExceptions;

public class UsersException extends Exception {
	/*
	 * Classe UsersException estende a classe Exception (necessita ser tratada,
	 * diferente da RuntimeException)
	 */
	private static final long serialVersionUID = 1L;

	public UsersException(String msg) {
		/*
		 * Construtor envia para a super-classe a mensagem entre aspas + a mensagem
		 * passada por parâmetro
		 */
		super("Users Exception Throwed: " + msg);
	}
}