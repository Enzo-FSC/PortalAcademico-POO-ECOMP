package resources;

import users.Docente;

public class Disciplina {
	protected String nomeDaDisciplina;
	protected String id;
	protected Docente docenteEncarregado;
	protected static final Integer limiteDeMatriculados = 40;

	public Disciplina(String nomeDaDisciplina, String id, Docente professorEncarregado) {
		this.nomeDaDisciplina = nomeDaDisciplina;
		this.id = id;
		this.docenteEncarregado = professorEncarregado;
	}

	// Métodos get dos 4 atributos da classe
	public String getNomeDaDisciplina() {
		return nomeDaDisciplina;
	}

	public String getId() {
		return id;
	}

	public Docente getDocenteEncarregado() {
		return docenteEncarregado;
	}

	public static Integer getLimitedematriculados() {
		return limiteDeMatriculados;
	}
}