package resources;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;

import applicationExceptions.ResourcesException;
import gui.ProgramaPrincipal;
import users.Docente;
import users.Estudante;

public abstract class LogDisciplinas extends Log {
	protected static int qntMatriculados = 0;

	public static List<Disciplina> listarDisciplinasEstudante(String usuario) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		Log.codificarUTF8(pathDisciplinasEstudante);
		Estudante a = LogCadastros.encontrarEstudante(usuario);
		List<Disciplina> listaDisciplinas = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(pathDisciplinasEstudante))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformação[] = linha.split(":");
				if (divideInformação.length >= 2) {
					if (divideInformação[0].equals(a.getNome())) {
						String divideCadeira[] = divideInformação[1].split(";");
						for (int i = 0; i < divideCadeira.length; i++) {
							String field[] = divideCadeira[i].split(",");
							listaDisciplinas
									.add(new Disciplina(field[0], field[1], LogCadastros.encontrarDocente(field[2])));
						}
					}
				}
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return listaDisciplinas;
	}

	public static List<Disciplina> listarDisciplinasDocente(String usuario) {
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		Log.codificarUTF8(pathDisciplinasDocente);
		Docente p = LogCadastros.encontrarDocente(usuario);
		List<Disciplina> listaDisciplinas = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(pathDisciplinasDocente))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformação[] = linha.split(":");
				if (divideInformação.length >= 2) {
					if (divideInformação[0].equals(p.getNome())
							|| divideInformação[0].equals(String.valueOf(p.getSiape()))) {
						String divideCadeira[] = divideInformação[1].split(";");
						for (int i = 0; i < divideCadeira.length; i++) {
							String field[] = divideCadeira[i].split(",");
							listaDisciplinas.add(new Disciplina(field[0], field[1], p));
						}
					}
				}
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return listaDisciplinas;
	}

	public static int quantidadeDeMatriculados(Disciplina d) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		Log.codificarUTF8(pathDisciplinasEstudante);
		qntMatriculados = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(pathDisciplinasEstudante))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformação[] = linha.split(":");
				if (divideInformação.length >= 2) {
					String divideCadeira[] = divideInformação[1].split(";");
					for (int i = 0; i < divideCadeira.length; i++) {
						String field[] = divideCadeira[i].split(",");
						if (field[0].equals(d.getNomeDaDisciplina())) {
							qntMatriculados++;
						}
					}
				}
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return qntMatriculados;
	}

	public static void atualizaMatriculados(Disciplina d) {
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		File arquivoDeEntrada = new File(pathDisciplinasDocente);
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha;
			StringBuilder sb = new StringBuilder();
			boolean primeiraLinha = true;

			while ((linha = br.readLine()) != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao.length >= 2) {
					String[] divideCadeira = divideInformacao[1].split(";");
					StringBuilder novaLinha = new StringBuilder(divideInformacao[0] + ":");

					for (int i = 0; i < divideCadeira.length; i++) {
						String[] field = divideCadeira[i].split(",");
						if (field[0].equals(d.getNomeDaDisciplina())) {
							int n = quantidadeDeMatriculados(d);
							field[2] = String.valueOf(n);
						}

						novaLinha.append(field[0]).append(",").append(field[1]).append(",").append(field[2]);
						if (i < divideCadeira.length - 1) {
							novaLinha.append(";");
						}
					}

					if (!primeiraLinha) {
						sb.append(System.lineSeparator()); // Adicione uma quebra de linha, exceto para a primeira linha
					} else {
						primeiraLinha = false;
					}
					sb.append(novaLinha);
				} else {
					if (!primeiraLinha) {
						sb.append(System.lineSeparator()); // Adicione uma quebra de linha, exceto para a primeira linha
					} else {
						primeiraLinha = false;
					}
					sb.append(linha);
				}
			}

			// Substitua o conteúdo original do arquivo pelo novo conteúdo
			Files.write(arquivoDeEntrada.toPath(), sb.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.codificarUTF8(pathDisciplinasDocente);
	}

	public static List<Estudante> estudantesMatriculados(Disciplina d) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		Log.codificarUTF8(pathDisciplinasEstudante);
		List<Estudante> listaAux = new ArrayList<Estudante>();
		try (BufferedReader br = new BufferedReader(new FileReader(pathDisciplinasEstudante))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformação[] = linha.split(":");
				if (divideInformação.length >= 2) {
					String divideCadeira[] = divideInformação[1].split(";");
					for (int i = 0; i < divideCadeira.length; i++) {
						String field[] = divideCadeira[i].split(",");
						if (field[0].equals(d.getNomeDaDisciplina())) {
							listaAux.add(LogCadastros.encontrarEstudante(divideInformação[0]));
						}
					}
				}
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return listaAux;
	}

	public static boolean atualizaArquivoNotasPorEstudante(Double n1, Double n2, Estudante a, Disciplina d) {
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		Log.codificarUTF8(pathNotasEstudante);
		File arquivoDeEntrada = new File(pathNotasEstudante);
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha;
			StringBuilder sb = new StringBuilder();
			boolean primeiraLinha = true;
			while ((linha = br.readLine()) != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao.length >= 2) {
					String[] divideCadeira = divideInformacao[1].split(";");
					StringBuilder novaLinha = new StringBuilder(divideInformacao[0] + ":");
					for (int i = 0; i < divideCadeira.length; i++) {
						String[] field = divideCadeira[i].split(",");
						if (field[0].equals(d.getNomeDaDisciplina())) {
							field[1] = String.valueOf(n1);
							field[2] = String.valueOf(n2);
						}

						novaLinha.append(field[0]).append(",").append(field[1]).append(",").append(field[2]);
						if (i < divideCadeira.length - 1) {
							novaLinha.append(";");
						}
					}

					if (!primeiraLinha) {
						sb.append(System.lineSeparator()); // Adicione uma quebra de linha, exceto para a primeira linha
					} else {
						primeiraLinha = false;
					}
					sb.append(novaLinha);
				} else {
					if (!primeiraLinha) {
						sb.append(System.lineSeparator()); // Adicione uma quebra de linha, exceto para a primeira linha
					} else {
						primeiraLinha = false;
					}
					sb.append(linha);
				}
			}
			// Substitua o conteúdo original do arquivo pelo novo conteúdo
			Files.write(arquivoDeEntrada.toPath(), sb.toString().getBytes());
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}
		Log.codificarUTF8(pathNotasEstudante);
		if (erro) {
			return false;
		} else {
			return true;
		}
	}

	public static Double mediaNotasPorDisciplina(Disciplina d) {
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		Log.codificarUTF8(pathNotasEstudante);
		Double soma = 0.0;
		try (BufferedReader br = new BufferedReader(new FileReader(pathNotasEstudante))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao.length >= 2) {
					String[] divideCadeira = divideInformacao[1].split(";");
					for (int i = 0; i < divideCadeira.length; i++) {
						String[] field = divideCadeira[i].split(",");
						if (field[0].equals(d.getNomeDaDisciplina())) {
							soma += (Double.parseDouble(field[1]) + Double.parseDouble(field[2])) / 2.0;
						}
					}
				}
				linha = br.readLine();
			}
			return soma / quantidadeDeMatriculados(d);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Erro ao ler o arquivo de notas por estudante!");
		return 0.0;
	}

	public static Double notaPorEstudanteEmDisciplina(Estudante a, Disciplina d) {
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		Log.codificarUTF8(pathNotasEstudante);
		Double media = 0.0;
		try (BufferedReader br = new BufferedReader(new FileReader(pathNotasEstudante))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao[0].equals(a.getNome())) {
					if (divideInformacao.length >= 2) {
						String[] divideCadeira = divideInformacao[1].split(";");
						for (int i = 0; i < divideCadeira.length; i++) {
							String[] field = divideCadeira[i].split(",");
							if (field[0].equals(d.getNomeDaDisciplina())) {
								media += (Double.parseDouble(field[1]) + Double.parseDouble(field[2])) / 2.0;
								return media;
							}
						}
					}
				}
				linha = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Erro ao ler o arquivo de notas por estudante!");
		return 0.0;
	}

	public static void realizarTrancamento(Estudante a, Disciplina d) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		File arquivoDeEntrada = new File(pathDisciplinasEstudante);
		boolean erro = false;
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			StringBuilder novoConteudo = new StringBuilder();
			boolean estudanteEncontrado = false;
			String linha;
			boolean primeiraLinha = true;

			while ((linha = br.readLine()) != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao[0].equals(a.getNome())) {
					estudanteEncontrado = true;
					if (divideInformacao.length >= 2) {
						String[] divideCadeira = divideInformacao[1].split(";");
						StringBuilder novaLinha = new StringBuilder(divideInformacao[0] + ":");
						boolean primeiraCadeira = true;

						for (int i = 0; i < divideCadeira.length; i++) {
							String[] field = divideCadeira[i].split(",");

							if (!field[0].equals(d.getNomeDaDisciplina())) {
								if (!primeiraCadeira) {
									novaLinha.append(";");
								}
								novaLinha.append(divideCadeira[i]);
								primeiraCadeira = false;
							}
						}

						if (!primeiraLinha) {
							novoConteudo.append(System.lineSeparator());
						}
						novoConteudo.append(novaLinha.toString());
						primeiraLinha = false;
					}
				} else {
					if (!primeiraLinha) {
						novoConteudo.append(System.lineSeparator());
					}
					novoConteudo.append(linha);
					primeiraLinha = false;
				}
			}

			if (estudanteEncontrado) {
				Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
				Log.codificarUTF8(pathDisciplinasEstudante);
				Log.codificarUTF8(pathNotasEstudante);
			} else {
				erro = true;
			}
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}

		arquivoDeEntrada = new File(pathNotasEstudante);

		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			StringBuilder novoConteudo = new StringBuilder();
			boolean estudanteEncontrado = false;
			String linha;
			boolean primeiraLinha = true;

			while ((linha = br.readLine()) != null) {
				String divideInformacao[] = linha.split(":");

				if (divideInformacao[0].equals(a.getNome())) {
					estudanteEncontrado = true;
					if (divideInformacao.length >= 2) {
						String[] divideCadeira = divideInformacao[1].split(";");
						StringBuilder novaLinha = new StringBuilder(divideInformacao[0] + ":");
						boolean primeiraCadeira = true;

						for (int i = 0; i < divideCadeira.length; i++) {
							String[] field = divideCadeira[i].split(",");

							if (!field[0].equals(d.getNomeDaDisciplina())) {
								if (!primeiraCadeira) {
									novaLinha.append(";");
								}
								novaLinha.append(divideCadeira[i]);
								primeiraCadeira = false;
							}
						}

						if (!primeiraLinha) {
							novoConteudo.append(System.lineSeparator());
						}
						novoConteudo.append(novaLinha.toString());
						primeiraLinha = false;
					}
				} else {
					if (!primeiraLinha) {
						novoConteudo.append(System.lineSeparator());
					}
					novoConteudo.append(linha);
					primeiraLinha = false;
				}
			}

			if (estudanteEncontrado) {
				Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
				Log.codificarUTF8(pathDisciplinasEstudante);
				Log.codificarUTF8(pathNotasEstudante);
				atualizaMatriculados(d);
				ProgramaPrincipal.showSuccessMessage(new JLabel("TRANCAMENTO REALIZADO COM SUCESSO!"));
			} else {
				erro = true;
			}
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO REALIZAR TRANCAMENTO!"));
		}
	}

	public static void cadastrarDisciplina(String nome, String codigo, Docente p) {
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		File arquivoDeEntrada = new File(pathDisciplinasDocente);
		StringBuilder novoConteudo = new StringBuilder();
		boolean disciplinaJaCadastrada = false;
		boolean erro = false;

		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			if (nome.equals("") || nome == null || codigo.equals("") || codigo == null || p == null) {
				throw new ResourcesException("Preenchimento incorreto dos campos de cadastro de disciplina");
			}
			String linha = br.readLine();

			while (linha != null) {
				String divideInformacao[] = linha.split(":");
				String docenteNome = divideInformacao[0];

				if (docenteNome.equals(p.getNome())) {
					StringBuilder novaLinha = new StringBuilder(linha);
					if (divideInformacao.length >= 2) {
						String divideCadeiras[] = divideInformacao[1].split(";");
						for (int i = 0; i < divideCadeiras.length; i++) {
							String fields[] = divideCadeiras[i].split(",");
							if (fields[0].equals(nome) || fields[1].equals(codigo)) {
								disciplinaJaCadastrada = true;
								break;
							}
						}
					}

					if (disciplinaJaCadastrada) {
						throw new ResourcesException("A disciplina informada já encontra-se cadastrada no sistema!");
					} else {
						if (divideInformacao.length == 1) {
							novaLinha.append(nome).append(",").append(codigo).append(",0");
						} else {
							novaLinha.append(";").append(nome).append(",").append(codigo).append(",0");
						}
					}

					novoConteudo.append(novaLinha);
				} else {
					novoConteudo.append(linha);
				}
				linha = br.readLine();
				if (!(linha == null)) {
					novoConteudo.append(System.lineSeparator());
				}
			}
			Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO CADASTRAR DISCIPLINA!"));
		} else {
			Log.codificarUTF8(pathDisciplinasDocente);
			ProgramaPrincipal.showSuccessMessage(new JLabel("DISCIPLINA CADASTRADA COM SUCESSO!"));
		}
	}

	public static void substituirDocente(String codigo, Docente novo, Docente atual) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		File arquivoDeEntrada = new File(pathDisciplinasDocente);
		String cadeiraMovida = null;
		StringBuilder novaLinhaDocenteAtual = new StringBuilder(atual.getNome() + ":");
		StringBuilder novaLinhaDocenteNovo = new StringBuilder(novo.getNome() + ":");
		StringBuilder novoConteudo = new StringBuilder();
		List<String> linhas = new ArrayList<>();
		boolean erro = false;

		try (BufferedReader br1 = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			if (novo.getNome().equals("Usuário Padrão") || atual.getNome().equals("Usuário Padrão") || codigo.equals("")
					|| codigo == null) {
				throw new ResourcesException("Preenchimento incorreto dos campos de substituição de docente");
			}
			String linha1 = br1.readLine();
			while (linha1 != null) {
				String divideInformacao[] = linha1.split(":");
				if (!(divideInformacao[0].equals(novo.getNome())) && !(divideInformacao[0].equals(atual.getNome()))) {
					linhas.add(linha1);
				}
				linha1 = br1.readLine();
			}
			br1.close();
			BufferedReader br2 = new BufferedReader(new FileReader(arquivoDeEntrada));
			String linha2 = br2.readLine();
			while (linha2 != null) {
				String divideInformacao[] = linha2.split(":");
				if (divideInformacao[0].equals(atual.getNome())) {
					if (divideInformacao.length >= 2) {
						String divideCadeira[] = divideInformacao[1].split(";");
						for (int i = 0; i < divideCadeira.length; i++) {
							String fields[] = divideCadeira[i].split(",");
							if (fields[1].equals(codigo)) {
								cadeiraMovida = divideCadeira[i].toString();
							} else {
								if (i >= divideCadeira.length - 1 || divideCadeira.length == 2) {
									novaLinhaDocenteAtual.append(divideCadeira[i]);
								} else {
									novaLinhaDocenteAtual.append(divideCadeira[i]).append(";");
								}
							}
						}
					} else {
						br2.close();
						throw new ResourcesException("O docente atual informado não está vinculado à disciplina!");
					}
				}
				linha2 = br2.readLine();
			}
			br2.close();
			BufferedReader br3 = new BufferedReader(new FileReader(arquivoDeEntrada));
			String linha3 = br3.readLine();
			while (linha3 != null) {
				String divideInformacao[] = linha3.split(":");
				if (divideInformacao[0].equals(novo.getNome())) {
					if (divideInformacao.length >= 2) {
						String divideCadeira[] = divideInformacao[1].split(";");
						for (int i = 0; i < divideCadeira.length; i++) {
							if (i >= divideCadeira.length - 1) {
								novaLinhaDocenteNovo.append(divideCadeira[i]).append(";").append(cadeiraMovida);
							} else {
								novaLinhaDocenteNovo.append(divideCadeira[i]);
								// Adiciona um ponto e vírgula somente se não for a última cadeira
								if (i < divideCadeira.length - 1) {
									novaLinhaDocenteNovo.append(";");
								}
							}
						}
					} else {
						novaLinhaDocenteNovo.append(cadeiraMovida);
					}
				}
				linha3 = br3.readLine();
			}
			br3.close();
			for (String l : linhas) {
				novoConteudo.append(l).append(System.lineSeparator());
			}
			novoConteudo.append(novaLinhaDocenteNovo).append(System.lineSeparator()).append(novaLinhaDocenteAtual);
			if (novoConteudo.length() > 0 && novoConteudo.charAt(novoConteudo.length() - 1) == ';') {
				novoConteudo.deleteCharAt(novoConteudo.length() - 1);
			}
			Files.write(arquivoDeEntrada.toPath(), novoConteudo.toString().getBytes());
		} catch (FileNotFoundException e) {
			erro = true;
			e.printStackTrace();
		} catch (IOException e) {
			erro = true;
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			erro = true;
			e.printStackTrace();
		} catch (ResourcesException e) {
			erro = true;
			e.printStackTrace();
		}
		if (!erro) {
			arquivoDeEntrada = new File(pathDisciplinasEstudante);
			try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
				String linha = br.readLine();
				StringBuilder novoConteudoEstudantes = new StringBuilder();

				while (linha != null) {
					String divideInformacao[] = linha.split(":");
					if (divideInformacao.length == 1) {
						novoConteudoEstudantes.append(linha);
						linha = br.readLine();
						if (linha != null) {
							novoConteudoEstudantes.append(System.lineSeparator());
						}
					} else if (divideInformacao.length >= 2) {
						String codigoDisciplina = divideInformacao[0];
						String[] divideCadeira = divideInformacao[1].split(";");
						StringBuilder novaLinha = new StringBuilder(codigoDisciplina + ":");
						boolean linhaModificada = false;

						for (int i = 0; i < divideCadeira.length; i++) {
							String fields[] = divideCadeira[i].split(",");
							String docente = fields[2];

							if (fields[1].equals(codigo) && docente.equals(atual.getNome())) {
								novaLinha.append(fields[0]).append(",").append(fields[1]).append(",")
										.append(novo.getNome());
								linhaModificada = true;
							} else {
								novaLinha.append(fields[0]).append(",").append(fields[1]).append(",").append(docente);
							}

							if (i < divideCadeira.length - 1) {
								novaLinha.append(";");
							}
						}

						if (linhaModificada) {
							novoConteudoEstudantes.append(novaLinha);
						} else {
							novoConteudoEstudantes.append(linha);
						}
						linha = br.readLine();
						if (linha != null) {
							novoConteudoEstudantes.append(System.lineSeparator());
						}
					}
				}
				br.close();
				Files.write(arquivoDeEntrada.toPath(), novoConteudoEstudantes.toString().getBytes());
			} catch (FileNotFoundException e) {
				erro = true;
				e.printStackTrace();
			} catch (IOException e) {
				erro = true;
				e.printStackTrace();
			}
		}
		if (erro) {
			ProgramaPrincipal.showErrorMessage(new JLabel("ERRO AO SUBSTITUIR DOCENTE"));
		} else {
			Log.codificarUTF8(pathDisciplinasEstudante);
			Log.codificarUTF8(pathDisciplinasDocente);
			ProgramaPrincipal.showSuccessMessage(new JLabel("SUCESSO AO SUBSTITUIR DOCENTE"));
		}
	}

	public static Disciplina encontrarDisciplina(String codigo) {
		String pathDisciplinasDocente = Log.getPath("logDisciplinasDocente.txt");
		File arquivoDeEntrada = new File(pathDisciplinasDocente);
		try (BufferedReader br = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha = br.readLine();
			while (linha != null) {
				String divideInformacao[] = linha.split(":");
				if (divideInformacao.length >= 2) {
					String divideCadeira[] = divideInformacao[1].split(";");
					for (int i = 0; i < divideCadeira.length; i++) {
						String fields[] = divideCadeira[i].split(",");
						if (fields[1].equals(codigo)) {
							return new Disciplina(fields[0], codigo,
									LogCadastros.encontrarDocente(divideInformacao[0]));
						}
					}
				}
				linha = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean solicitarMatricula(String usuario, String codigo) {
		String pathDisciplinasEstudante = Log.getPath("logDisciplinasEstudante.txt");
		String pathNotasEstudante = Log.getPath("logNotasPorEstudante.txt");
		File arquivoDeEntrada = new File(pathDisciplinasEstudante);
		Estudante a = LogCadastros.encontrarEstudante(usuario);
		Disciplina d = encontrarDisciplina(codigo);
		StringBuilder novoConteudo1 = new StringBuilder();
		StringBuilder novoConteudo2 = new StringBuilder();
		boolean estudanteEncontrado1 = false;
		boolean estudanteEncontrado2 = false;
		if (d == null || quantidadeDeMatriculados(d) == 40) {
			return false;
		}
		try (BufferedReader br1 = new BufferedReader(new FileReader(arquivoDeEntrada))) {
			String linha1 = br1.readLine();
			while (linha1 != null) {
				String divideInformacao[] = linha1.split(":");
				if (divideInformacao[0].equals(a.getNome())) {
					estudanteEncontrado1 = true;
					if (divideInformacao.length == 1) {
						novoConteudo1.append(linha1).append(d.getNomeDaDisciplina()).append(",").append(d.getId())
								.append(",").append(d.getDocenteEncarregado().getNome());
					} else {
						novoConteudo1.append(linha1).append(";").append(d.getNomeDaDisciplina()).append(",")
								.append(d.getId()).append(",").append(d.getDocenteEncarregado().getNome());
					}
				} else {
					novoConteudo1.append(linha1);
				}
				linha1 = br1.readLine();
				if (linha1 != null) {
					novoConteudo1.append(System.lineSeparator());
				}
			}
			br1.close();
			Files.write(arquivoDeEntrada.toPath(), novoConteudo1.toString().getBytes());

			arquivoDeEntrada = new File(pathNotasEstudante);
			BufferedReader br2 = new BufferedReader(new FileReader(arquivoDeEntrada));
			String linha2 = br2.readLine();
			while (linha2 != null) {
				String divideInformacao[] = linha2.split(":");
				if (divideInformacao[0].equals(a.getNome())) {
					estudanteEncontrado2 = true;
					if (divideInformacao.length == 1) {
						novoConteudo2.append(linha2).append(d.getNomeDaDisciplina()).append(",").append("0.0")
								.append(",").append("0.0");
					} else {
						novoConteudo2.append(linha2).append(";").append(d.getNomeDaDisciplina()).append(",")
								.append("0.0").append(",").append("0.0");
					}
				} else {
					novoConteudo2.append(linha2);
				}
				linha2 = br2.readLine();
				if (linha2 != null) {
					novoConteudo2.append(System.lineSeparator());
				}
			}
			br2.close();
			Files.write(arquivoDeEntrada.toPath(), novoConteudo2.toString().getBytes());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (estudanteEncontrado1 && estudanteEncontrado2) {
			atualizaMatriculados(d);
			return true;
		} else {
			return false;
		}
	}
}